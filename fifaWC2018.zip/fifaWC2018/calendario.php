<?php
include("top.php");
include 'isAlterado.php';

if (isset($_POST['sub'])) {
    data_evento($_POST['data_inicio'], $_POST['data_fim']);
    redirect('calendario.php');
}
if (isset($_GET['remover'])) {
    remover_jogo_provisorio($_GET['remover']);
}
if (get_evento() == null || isset($_GET['edi'])) {
    ?>
    <div class="registo">

        <h1>Calendário</h1>
        <form method="post">
            <br>
            <p>Data inicial do evento: <input type="date" name="data_inicio" value=""></p>
            <br>
            <p>Data final do evento: <input type="date" name="data_fim" value=""></p>
            <br>
            <input type="submit" name="sub" value="submeter">
        </form>

    </div>
    <?php
} else {
    if (isset($_POST['ex_cod_sel1'])) {
        atualiza_jogos($_POST['id_jogo'], $_POST["data_jogo"], $_POST['estadio']);
    }
    if (isset($_POST['id_jogo'])) {
        if ($_POST["selecao1"] == $_POST["selecao2"]) {
            echo "<script language=javascript>alert( 'Uma seleçao não pode jogar contra ela própria' );</script>";
        } else if (verificarSelecoes($_POST["selecao1"], $_POST["selecao2"]) == false) {
            update_grupo($_POST['id_jogo']);
            cria_jogos($_POST['id_jogo'], $_POST["data_jogo"], $_POST["selecao1"], $_POST["selecao2"], $_POST['estadio']);
        } else {
            echo "<script language=javascript>alert( 'Estas seleções já se encontraram' );</script>";
        }
    }
    if (isset($_GET['terminar'])) {
        
        $cod_sel1 = $_GET['cod_sel1'];
        $cod_sel2 = $_GET['cod_sel2'];
        $id_jogo = $_GET['id_jogo'];
        mail_jogo($id_jogo,$cod_sel1, $cod_sel2);
        set_jogo_terminado($_GET['id_jogo']);

        if (get_fase($cod_sel1) == 1 && get_fase($cod_sel2) == 1) {
            set_pontos($id_jogo, $cod_sel1, $cod_sel2);
            $selecoes = get_selecoes_by_grupo($_GET['id_grupo']);
            $n_jogos = 0;
            for ($i = 0; $i < count($selecoes); $i++) {
                $n_jogos+=contar_jogos_grupo($selecoes[$i]['cod_sel']);
            }
            if ($n_jogos == 12) {
                $id_grupo = $_GET['id_grupo'];
                $grupo = get_grupo_ordenado($id_grupo);
                $primeira = $grupo[0]['cod_sel'];
                $segunda = $grupo[1]['cod_sel'];
                set_fase($primeira);
                set_fase($segunda);
                if ($id_grupo == 1) {
                    $id_apuramento1 = 1;
                    $id_apuramento2 = 9;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 2) {
                    $id_apuramento1 = 10;
                    $id_apuramento2 = 2;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 3) {
                    $id_apuramento1 = 3;
                    $id_apuramento2 = 11;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 4) {
                    $id_apuramento1 = 12;
                    $id_apuramento2 = 4;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 5) {
                    $id_apuramento1 = 5;
                    $id_apuramento2 = 13;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 6) {
                    $id_apuramento1 = 14;
                    $id_apuramento2 = 6;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 7) {
                    $id_apuramento1 = 7;
                    $id_apuramento2 = 15;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                } else if ($id_grupo == 8) {
                    $id_apuramento1 = 16;
                    $id_apuramento2 = 8;
                    set_apurada($primeira, $id_apuramento1);
                    set_apurada($segunda, $id_apuramento2);
                }
                redirect("eliminatorias.php?oitavos=1&id_apuramento1=$id_apuramento1&id_apuramento2=$id_apuramento2&cod_sel1=$primeira&cod_sel2=$segunda");
            }
        }
        if (get_fase($cod_sel1) == 2 && get_fase($cod_sel2) == 2) {
            if (resultado($id_jogo, $cod_sel1) > resultado($id_jogo, $cod_sel2)) {
                $vencedora = $cod_sel1;
                set_fase($vencedora);
            } else {
                $vencedora = $cod_sel2;
                set_fase($vencedora);
            }
            if (get_oponente(1) == $vencedora || get_oponente(2) == $vencedora) {
                $id_apuramento = 17;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(3) == $vencedora || get_oponente(4) == $vencedora) {
                $id_apuramento = 18;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(5) == $vencedora || get_oponente(6) == $vencedora) {
                $id_apuramento = 19;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(7) == $vencedora || get_oponente(8) == $vencedora) {
                $id_apuramento = 20;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(9) == $vencedora || get_oponente(10) == $vencedora) {
                $id_apuramento = 21;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(11) == $vencedora || get_oponente(12) == $vencedora) {
                $id_apuramento = 22;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(13) == $vencedora || get_oponente(14) == $vencedora) {
                $id_apuramento = 23;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(15) == $vencedora || get_oponente(16) == $vencedora) {
                $id_apuramento = 24;
                set_apurada($vencedora, $id_apuramento);
            }
            redirect("eliminatorias.php?quartos=1&id_apuramento=$id_apuramento&cod_sel=$vencedora");
        }
        if (get_fase($cod_sel1) == 3 && get_fase($cod_sel2) == 3) {
            if (resultado($id_jogo, $cod_sel1) > resultado($id_jogo, $cod_sel2)) {
                $vencedora = $cod_sel1;
                set_fase($vencedora);
            } else {
                $vencedora = $cod_sel2;
                set_fase($vencedora);
            }
            if (get_oponente(17) == $vencedora || get_oponente(18) == $vencedora) {
                $id_apuramento = 25;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(19) == $vencedora || get_oponente(20) == $vencedora) {
                $id_apuramento = 26;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(21) == $vencedora || get_oponente(22) == $vencedora) {
                $id_apuramento = 27;
                set_apurada($vencedora, $id_apuramento);
            } else if (get_oponente(23) == $vencedora || get_oponente(24) == $vencedora) {
                $id_apuramento = 28;
                set_apurada($vencedora, $id_apuramento);
            }
            redirect("eliminatorias.php?meias=1&id_apuramento=$id_apuramento&cod_sel=$vencedora");
        }

        if (get_fase($cod_sel1) == 4 && get_fase($cod_sel2) == 4) {
            if (resultado($id_jogo, $cod_sel1) > resultado($id_jogo, $cod_sel2)) {
                $vencedora = $cod_sel1;
                $derrotada = $cod_sel2;
                set_fase($vencedora);
                set_fase($vencedora);
                set_fase($derrotada);
            } else {
                $derrotada = $cod_sel1;
                $vencedora = $cod_sel2;
                set_fase($vencedora);
                set_fase($vencedora);
                set_fase($derrotada);
            }
            if (get_oponente(25) == $vencedora || get_oponente(26) == $vencedora) {
                $id_apuramento1 = 31;
                $id_apuramento2 = 29;
                set_apurada($vencedora, $id_apuramento1);
                set_apurada($derrotada, $id_apuramento2);
            } else if (get_oponente(27) == $vencedora || get_oponente(28) == $vencedora) {
                $id_apuramento1 = 32;
                $id_apuramento2 = 30;
                set_apurada($vencedora, $id_apuramento1);
                set_apurada($derrotada, $id_apuramento2);
            }
            redirect("eliminatorias.php?finais=1&id_apuramento1=$id_apuramento1&id_apuramento2=$id_apuramento2&cod_sel1=$vencedora&cod_sel2=$derrotada");
        }
        
    }
    ?>
    <div class="fundo">
        <div>
            <h1>Calendário</h1>
            <form action="registarJogo.php">
                <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?><input class="criar" type="submit" value="Registar Jogo"><?php } ?>
                <h4>O EVENTO DECORRERÁ ENTRE: <?= get_evento()[0] ?> e <?= get_evento()[1] ?>  <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?><a href="calendario.php?edi=1"><input type="button" value="editar"></a><?php } ?></h4>

            </form>
            <br>

        </div>
        <div >
            <div class="calendarios"> <?php
            calendario();
                ?>
                <br/>
            </div>
            <br/>
            <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?>
                <div class="calendarios"> 
                    <?php calendario_provisorio() ?>

                </div> <?php } ?>
        </div>
    </div>
    <?php
} 