<?php
include 'top.php';
include 'isAlterado.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Fifa World Cup 2018</title>
        <meta charset="UTF-8">
        <link rel="icon" href="Imagens/mundial.png" type="image/png">
    </head>
    <body>
        <div style="margin-left: 25%;margin-top: 5%">
        <iframe width="600" height="330" src="//www.youtube.com/embed/5Szi_OIMEMc" frameborder="0" allowfullscreen></iframe>
    </div>    
        </body>
</html>
<?php include 'header.php';

