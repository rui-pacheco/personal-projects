<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 2) {

if (isset($_POST["nome"], $_POST["cidade"], $_POST["lotacao"], $_POST["latitude"], $_POST["longitude"])) {
    atualiza_estadios($_POST["nome"], $_POST["cidade"], $_POST["lotacao"], $_POST["latitude"], $_POST["longitude"],$_GET['id_estadio']);
    echo "<script language=javascript>alert( 'Estadio atualizado com sucesso!' );</script>";
    redirect("verEstadios.php");
}
?>
<div class="registo">
    <h1> Editar Estádio </h1>
    <form method="post">
        <p>Nome: <input type="text" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="nome" value="<?=$_GET['nome']?>"></p>
        <p>Cidade: <input type="text" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="cidade" value="<?=$_GET['cidade']?>"></p>
        <p>Lotação: <input type="number" name="lotacao" min="0" title="Apenas numeros" pattern="[0-9]+" value=<?=$_GET['lotacao']?>></p>
        <p>Latitude: <input type="number" name="latitude" value=<?=$_GET['latitude']?>></p>
        <p>Longitude: <input type="number" name="longitude" value=<?=$_GET['longitude']?>></p>
        <input type="submit" value="Editar">
    </form>
</div>
<?php } else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
