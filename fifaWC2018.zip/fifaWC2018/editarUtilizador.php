<?php
include("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

    if (isset($_POST['morada'])) {
        editaUtilizador_admin($_GET["id"], $_POST['nome'], $_POST['mail'], $_POST['data'], $_POST['tel'], $_POST['morada']);
        echo "<script language=javascript>alert( 'Utilizador editado com sucesso!' );</script>";
    }
    if (isset($_GET["nome"])) {
        $utilizador = getUtilizadores_by_id($_GET["id"]);
    }
    ?>
    <div class="registo">
        <form method="post">
            <h1> <input type="text" name="nome" value="<?= $_GET["nome"] ?>"> - <?= $_GET["perfil"] ?></h1>
            <p><span class="upc"><b>País</b>:</span> <?= $utilizador["Selecoes_cod_sel"] ?></p>
            <p><span class="upc"><b>Email</b>:</span> <input type="email" name="mail" required value="<?= $utilizador["mail"] ?>"></p>
            <p><span class="upc"><b>Data de Nascimento</b>:</span>  <input type="date" required name="data" placeholder="aaaa-mm-dd" value=<?= $utilizador["data_nasc"] ?>></p>
            <p><span class="upc"><b>Telemóvel</b>:</span>  <input type="tel" name="tel" title="Apenas numeros" pattern="[0-9]+" required value="<?= $utilizador["telemovel"] ?>"></p>
            <p><span class="upc"><b>Morada</b>:</span>  <input type="text" name="morada" required value="<?= $utilizador["morada"] ?>"></p>
            <input type="submit" value="Editar">
        </form>
        <?php
        include("comentarios.php");
        ?>
    </div>
    <?php
    } else {
    echo "<script language=javascript>alert('Não tem permissões para aceder a esta página');</script>";
    }
    