<?php
include 'top.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
    if (isset($_POST["sel1"])) {
        if (atribuir_golos($_POST["minuto_sel1"], $_POST["autogolo_sel1"], $_GET["id_jogo"], $_POST["autor_golo_sel1"], $_GET["cod_sel1"], $_GET["cod_sel2"])) {
            echo "<script language=javascript>alert( 'Golo adicionado com sucesso' );</script>";
        }
    }
    if (isset($_POST["sel2"])) {
        if (atribuir_golos($_POST["minuto_sel2"], $_POST["autogolo_sel2"], $_GET["id_jogo"], $_POST["autor_golo_sel2"], $_GET["cod_sel1"], $_GET["cod_sel2"])) {
            echo "<script language=javascript>alert( 'Golo adicionado com sucesso!' );</script>";
        }
    }
    ?>

    <div class="fundo">
        <div style="display: inline-block;margin-left:20%">
            <form method="post">
                <h1><?= $_GET['selecao1'] . ' - ' . resultado($_GET['id_jogo'], $_GET['cod_sel1']) ?></h1>
                <br>
                <h2>Golos</h2>
                <p>Autogolo: Sim <input type="radio" name="autogolo_sel1" value="1" >
                    Não<input type="radio" name="autogolo_sel1" value="0" checked>
                    <br>
                    <br>
                    Minuto: <input type="number" name="minuto_sel1" min="0" max="120" value="" title="Apenas numeros" pattern="[0-9]+" required>
                    <br>
                    <br>
                    Autor do golo:
                    <select name="autor_golo_sel1">
                        <?php
                        $jogadores_uti_sel1 = get_jogadores_uti_by_cod_sel($_GET['cod_sel1'], $_GET['id_jogo']);
                        for ($i = 0; $i < count($jogadores_uti_sel1); $i++) {
                            ?>
                            <option value="<?= $jogadores_uti_sel1[$i]['id_jogador'] ?>"><?= $jogadores_uti_sel1[$i]['nome'] ?></option>
                        <?php }
                        ?>
                    </select>
                </p>
                <br>
                <input type="hidden" name="id_jogo" value="<?= $_POST['id_jogo'] ?>">
                <input type="hidden" name="cod_sel1" value="<?= $_POST['cod_sel1'] ?>">
                <input type="hidden" name="cod_sel2" value="<?= $_POST['cod_sel2'] ?>">
                <input type="hidden" name="sel1" value="1">


                <input type="submit" value="adicionar golo">
            </form><br>
        </div>
        <div style="display: inline-block;margin-left:10%">
            <form method="post">

                <h1><?= resultado($_GET['id_jogo'], $_GET['cod_sel2']) . ' - ' . $_GET['selecao2'] ?></h1>
                <br>
                <h2>Golos</h2>
                <p>Autogolo: Sim <input type="radio" name="autogolo_sel2" value="1" >
                    Não<input type="radio" name="autogolo_sel2" value="0" checked>
                    <br>
                    <br>
                    Minuto: <input type="number" name="minuto_sel2" min="0" max="120" value="" title="Apenas numeros" pattern="[0-9]+" required>
                    <br>
                    <br>
                    Autor do golo:
                    <select name="autor_golo_sel2">
                        <?php
                        $jogadores_uti_sel2 = get_jogadores_uti_by_cod_sel($_GET['cod_sel2'], $_GET['id_jogo']);
                        for ($i = 0; $i < count($jogadores_uti_sel2); $i++) {
                            ?>
                            <option value="<?= $jogadores_uti_sel2[$i]['id_jogador'] ?>"><?= $jogadores_uti_sel2[$i]['nome'] ?></option>
                        <?php }
                        ?>
                    </select>
                </p>
                <br>
                <input type="hidden" name="id_jogo" value="<?= $_POST['id_jogo'] ?>">
                <input type="hidden" name="cod_sel2" value="<?= $_POST['cod_sel2'] ?>">
                <input type="hidden" name="cod_sel1" value="<?= $_POST['cod_sel1'] ?>">
                <input type="hidden" name="sel2" value="2">
                <input type="submit" value="adicionar golo">
            </form><br></div>

    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}