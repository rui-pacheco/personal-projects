<?php
include("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 2) {

if (isset($_POST["nome"], $_POST["cidade"], $_POST["lotacao"], $_POST["latitude"], $_POST["longitude"])) {
    regista_estadio($_POST["nome"], $_POST["cidade"], $_POST["lotacao"], $_POST["latitude"], $_POST["longitude"]);
    echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
}
?>
<div class="registo">
    <h1> Registar Estádio </h1>
    <form method="post">
        <p>Nome: <input type="text" name="nome" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value=""></p>
        <p>Cidade: <input type="text" name="cidade" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value=""></p>
        <p>Lotação: <input type="number" title="Apenas numeros" min="0" pattern="[0-9]+" name="lotacao" value=""></p>
        <p>Latitude: <input type="number" name="latitude" value=""></p>
        <p>Longitude: <input type="number" name="longitude" value=""></p>
        <input type="submit" value="Registar">
    </form>
</div>
<?php
} else {
echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}