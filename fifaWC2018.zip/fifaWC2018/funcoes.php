<?php
require_once 'mysql.connect.php';

function ligar_base_dados() {
    $ligacao = mysql_connect(MYSQL_SERVER, MYSQL_USERNAME, MYSQL_PASSWORD) or die('Erro ao ligar ao servidor...');
    mysql_select_db(MYSQL_DATABASE, $ligacao) or die('Erro ao selecionar a base de dados...');
    mysql_query("SET NAMES utf8");
    return $ligacao;
}

function getUtilizadores() {
    $ligacao = ligar_base_dados();
    $query = "select * from utilizadores where Perfis_id_perfil<>1 order by Perfis_id_perfil";
    $resultado = mysql_query($query, $ligacao);
    $utilizadores = array();
    if ($resultado == false) {
        echo "<script language=javascript>alert( 'Ainda não existem outros utilizadores!' );</script>";
    } else {
        while ($utilizador = mysql_fetch_assoc($resultado)) {
            $utilizadores[] = $utilizador;
        }
    }
    mysql_close($ligacao);
    return $utilizadores;
}

function existe_jogo($id_grupo) {
    $ligacao = ligar_base_dados();
    $query = "select * from selecoesdestacadas s, selecoes c, jogos j where c.cod_sel=s.selecoes_cod_sel and j.id_jogo=s.Jogos_id_jogo and c.Grupos_id_grupo=$id_grupo and j.Fases_id_fase=2 and c.Fases_id_fase=2";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    if ($resultado !== false) {
        $jogo = true;
    } else {
        $jogo = false;
    }
    mysql_close($ligacao);
    return $jogo;
}

function editaUtilizador_admin($id, $nome, $mail, $data, $tel, $morada) {
    $ligacao = ligar_base_dados();
    $query = "UPDATE utilizadores set nome = '$nome', data_nasc='$data',mail='$mail', telemovel=$tel, morada='$morada'"
            . "  where id_utilizador = $id";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function getUtilizadores_by_id($id) {
    $ligacao = ligar_base_dados();
    $query = "select * from utilizadores where id_utilizador='$id'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $utilizador = mysql_fetch_assoc($resultado);
    }
    mysql_close($ligacao);
    return $utilizador;
}

function get_nomeEstadio($id_estadio = NULL) {
    $ligacao = ligar_base_dados();
    if ($id_estadio != null) {
        $query = "select nome from Estadios where id_estadio = $id_estadio";
    } else {
        $query = "select nome from Estadios where id_estadio is null";
    }

    $resultado = mysql_query($query, $ligacao);

    if (mysql_num_rows($resultado) == false) {
        $nome[0] = "por definir";
    } else {
        $nome = mysql_fetch_array($resultado);
        $nome[0] = $nome['nome'];
    }

    return $nome[0];
}

function calendario() {
    $ligacao = ligar_base_dados();
    $query = "select j.data_jogo, s.Grupos_id_grupo, g.descricao, f.fase,  f.id_fase, e.n_golos, s.cod_sel, j.Estadios_id_estadio, s.pais, j.id_jogo
from jogos j, selecoesdestacadas e, fases f, selecoes s, grupos g
where  e.Jogos_id_jogo=j.id_jogo and s.Grupos_id_grupo=g.id_grupo and s.cod_sel=e.Selecoes_cod_sel
and f.id_fase=j.Fases_id_fase  order by j.data_jogo asc, j.id_jogo asc, e.Selecoes_cod_sel asc;";
    $resultado = mysql_query($query, $ligacao);

    $jogos = array();
    ?>
    <table class="tablePequena">
        <tr>
            <th colspan="7">Calendário </th>
        </tr>
        <tr>
            <th>ID</th>
            <th>Data</th>
            <th>Fase</th>
            <th>Seleção</th>
            <th>Resultado</th>
            <th>Seleção</th>
            <th>Estádio</th>


        </tr>
        <?php
        if ($resultado == false) {
            die('Error :' . \mysql_error($ligacao));
        } else {
            while ($jogo = mysql_fetch_array($resultado)) {
                $jogos[] = $jogo;
                if (count($jogos) == 2) {
                    $id_jogo = $jogos[0]['id_jogo'];
                    $estadio = get_nomeEstadio($jogos[1]['Estadios_id_estadio']);
                    $golos = get_golos($jogos[0]['id_jogo']);
                    $sel1_golos = 0;
                    $sel2_golos = 0;
                    for ($z = 0; $z < count($golos); $z++) {
                        if (($golos[$z]['pais'] == $jogos[0]['pais']) || ($golos[$z]['pais'] == $jogos[1]['pais'] && $golos[$z]['autogolo'] == 1)) {
                            $sel1_golos++;
                        } else {
                            $sel2_golos++;
                        }
                    }
                    ?>
                    <tr>
                        <td><?= $jogos[0]['id_jogo'] ?></td>
                        <td><?= $jogos[0]['data_jogo'] ?></td>
                        <td><?= $jogos[0]['fase'] ?></td>
                        <td><?= $jogos[0]['pais'] ?></td>
                        <td><?= $sel1_golos . " - " . $sel2_golos ?></td>
                        <td><?= $jogos[1]['pais'] ?></td>
                        <td><?= $estadio ?></td>
                        <?php if (jogo_terminado($id_jogo)) { ?>
                            <td><a href="verJogo.php?id_jogo=<?= $id_jogo ?>&data=<?= $jogos[0]['data_jogo'] ?>&fase=<?= $jogos[0]['fase'] ?>& estadio=<?= $estadio ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                   cod_sel1=<?= $jogos[0]['cod_sel'] ?>&golos1=<?= $sel1_golos ?>&golos2=<?= $sel2_golos ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>">
                                    <input type="submit" value="ver"></a>

                        <?php } else { ?><td><a href="instrucoes.php?id_jogo=<?= $id_jogo ?>&id_grupo=<?= $jogos[0]['Grupos_id_grupo'] ?>&grupo=<?= $jogos[0]['descricao'] ?>&data_jogo=<?= $jogos[0]['data_jogo'] ?>
                                   &id_fase=<?= $jogos[0]['id_fase'] ?>&fase=<?= $jogos[0]['fase'] ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                   cod_sel1=<?= $jogos[0]['cod_sel'] ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>&estadio=<?= $estadio ?>&id_estadio=<?= $jogos[1]['Estadios_id_estadio'] ?>">
                                    <input type="submit" value="instruções"></a><?php
                                if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
                                    ?>

                                    <a href="editarJogo.php?id_jogo=<?= $id_jogo ?>&id_grupo=<?= $jogos[0]['Grupos_id_grupo'] ?>&grupo=<?= $jogos[0]['descricao'] ?>&data_jogo=<?= $jogos[0]['data_jogo'] ?>
                                       &id_fase=<?= $jogos[0]['id_fase'] ?>&fase=<?= $jogos[0]['fase'] ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                       cod_sel1=<?= $jogos[0]['cod_sel'] ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>&estadio=<?= $estadio ?>&id_estadio=<?= $jogos[1]['Estadios_id_estadio'] ?>">
                                        <input type="submit" value="editar"></a>
                                    <a href="atualizaJogo.php?id_jogo=<?= $id_jogo ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                       cod_sel1=<?= $jogos[0]['cod_sel'] ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>">
                                        <input type="submit" value="atualizar"></a>
                                    <a href="adicionarGolos.php?id_jogo=<?= $id_jogo ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                       cod_sel1=<?= $jogos[0]['cod_sel'] ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>">
                                        <input type="submit" value="adicionar golos"></a>
                                    <a href="adicionarCartoes.php?id_jogo=<?= $id_jogo ?>&selecao1=<?= $jogos[0]['pais'] ?>&
                                       cod_sel1=<?= $jogos[0]['cod_sel'] ?>&selecao2=<?= $jogos[1]['pais'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>">
                                        <input type="submit" value="adicionar cartões"></a>
                                    <a href="adicionarArbitros.php?id_jogo=<?= $id_jogo ?>">
                                        <input type="submit" value="Adicionar árbitros"></a>
                                    <a href="calendario.php?terminar=1&id_jogo=<?= $id_jogo ?>&cod_sel1=<?= $jogos[0]['cod_sel'] ?>&cod_sel2=<?= $jogos[1]['cod_sel'] ?>&id_grupo=<?= $jogos[0]['Grupos_id_grupo'] ?>">
                                        <input type="button" value="terminar jogo"></a>

                                    <?php
                                }
                            }
                            ?>

                        </td></tr>

                    <?php
                    unset($jogos);
                }
            }
        }
        ?>
    </table>
    <?php
}

function get_cordenadas($id_estadio) {
    $ligacao = ligar_base_dados();
    $query = "select latitude,longitude from estadios where id_estadio=$id_estadio";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $i = mysql_fetch_array($resultado);
    return $i['latitude'] . "," . $i['longitude'];
}

function get_cidade($id_estadio) {
    $ligacao = ligar_base_dados();

    $query = "select cidade from Estadios where id_estadio = $id_estadio";


    $resultado = mysql_query($query, $ligacao);

    if (mysql_num_rows($resultado) == false) {
        $nome[0] = "por definir";
    } else {
        $nome = mysql_fetch_array($resultado);
        $nome[0] = $nome['cidade'];
    }

    return $nome[0];
}

function num_grupos() {
    $ligacao = ligar_base_dados();
    $query = "select count(*) from grupos";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $num_grupos = mysql_fetch_array($resultado);
    }
    mysql_close($ligacao);
    return $num_grupos[0];
}

function calendario_provisorio() {
    $ligacao = ligar_base_dados();
    $query = "select id_jogo, data_jogo from jogos where Fases_id_fase is null";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <table class="tablePequena">
        <tr>
            <th colspan="2">Calendário Provisório</th>
        </tr>
        <tr>
            <th>Id Jogo</th>
            <th>Data</th>
        </tr>
        <?php
        if ($resultado == false) {
            die('Error :' . \mysql_error($ligacao));
        } else {
            while ($jogo = mysql_fetch_array($resultado)) {
                $id_jogo = $jogo['id_jogo'];
                $data = $jogo['data_jogo'];
                ?>
                <tr>
                    <td><?= $id_jogo ?></td>
                    <td><?= $data ?></td>
                    <td><a href="editarJogo.php?provi=1&id_jogo=<?= $id_jogo ?>&data_jogo=<?= $data ?>">
                            <input type="submit" value="editar"></a></td> 
                    <td><a href="verGrupos.php?remover=<?= $id_jogo ?>">
                            <input type="submit" value="remover"></a></td>
                </tr>

                <?php
            }
        }
        ?>
    </table>
    <?php
}

function jogo_terminado($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "Select terminado from jogos where id_jogo=$id_jogo";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $terminado = $linha['terminado'];
    mysql_close($ligacao);
    return $terminado;
}

function golos_sofr($cod_sel) {
    $ligacao = ligar_base_dados();
    $golos_sofr = get_golos_sofr($cod_sel);
    $golos_sofr++;
    $query = "update selecoes set golos_sofr=$golos_sofr where cod_sel='$cod_sel'";
    mysql_query($query, $ligacao);
}

function procura($procura) {
    $ligacao = ligar_base_dados();
    $query = "select * from jogadores where nome like '%$procura%'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        ?>
        <div>
            <table class="tablePequena">
                <tr> 
                    <th> Nome</th>
                </tr>
                <?php
                while ($jogador = mysql_fetch_assoc($resultado)) {
                    $nome = $jogador["nome"];
                    $id = $jogador["id_jogador"];
                    ?>

                    <tr>
                        <td><?php
                            if ($jogador !== null) {
                                echo $nome;
                                ?></td>
                            <td>
                                <a href="verJogador.php?id_jogador=<?= $id ?>&nome=<?= $nome ?>"><input type="button" value="Ver"></a>
                            </td>
                        </tr>
                        <?php
                    }mysql_close($ligacao);
                    die();
                }if ($jogador == null) {
                    ?><tr>
                        <td>
                            Não existem jogadores com esse nome</td><?php
                    }
                    mysql_close($ligacao);
                    ?></table>
        </div>
        <?php
    }
}

function registar_grupo($descricao) {
    $ligacao = ligar_base_dados();
    $descricao = mysql_real_escape_string($descricao);

    $query = "INSERT INTO `grupos`(descricao) VALUES ('$descricao')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remove_grupo($id_grupo) {
    $selecoes = get_selecoes_by_grupo($id_grupo);
    $ligacao = ligar_base_dados();
    for ($i = 0; $i < count($selecoes); $i++) {
        $cod_sel = ($selecoes[$i]["cod_sel"]);
        $query = "update selecoes set Grupos_id_grupo=NULL where cod_sel='$cod_sel'";
        $resultado = mysql_query($query, $ligacao) or die('Error: ' . \mysql_error($ligacao));
    }
    $query = "delete from grupos where id_grupo=$id_grupo";
    $resultado = mysql_query($query, $ligacao) or die('Error: ' . \mysql_error($ligacao));

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {

        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function adiciona_selecao_grupo($cod_sel, $id_grupo) {
    $ligacao = ligar_base_dados();
    $query = "update selecoes set Grupos_id_grupo=$id_grupo where cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function set_apurada($cod_sel, $id_apuramento) {
    $ligacao = ligar_base_dados();
    $query = "update apuramentos set Selecoes_cod_sel='$cod_sel' where id_apuramento=$id_apuramento";
    mysql_query($query, $ligacao) or die("sou burro" . mysql_error());
    mysql_close($ligacao);
}

function get_oponente($id_apuramento) {
    $ligacao = ligar_base_dados();
    $query = "select Selecoes_cod_sel from apuramentos where id_apuramento=$id_apuramento";
    $resultado = mysql_query($query, $ligacao) or die("sou mano" . mysql_error());
    $linha = mysql_fetch_array($resultado);
    $cod_sel = $linha['Selecoes_cod_sel'];
    mysql_close($ligacao);
    return $cod_sel;
}

function get_nome_oponente($id_apuramento) {
    $ligacao = ligar_base_dados();
    $query = "select pais from apuramentos,selecoes where id_apuramento=$id_apuramento and Selecoes_cod_sel=cod_sel";
    $resultado = mysql_query($query, $ligacao) or die("sou mano" . mysql_error());
    $linha = mysql_fetch_array($resultado);
    $pais = $linha['pais'];
    mysql_close($ligacao);
    return $pais;
}

function set_pontos($id_jogo, $cod_sel1, $cod_sel2) {
    $ligacao = ligar_base_dados();

    if (resultado($id_jogo, $cod_sel1) == resultado($id_jogo, $cod_sel2)) {
        $query = "update selecoes set pontos=pontos+1 where cod_sel='$cod_sel1'";
        $query1 = "update selecoes set pontos=pontos+1 where cod_sel='$cod_sel2'";
        mysql_query($query) or die("sou burro" . mysql_error());
        mysql_query($query1) or die("sou burro" . mysql_error());
    } else if (resultado($id_jogo, $cod_sel1) > resultado($id_jogo, $cod_sel2)) {
        $query = "update selecoes set pontos=pontos+3 where cod_sel='$cod_sel1'";
        mysql_query($query) or die("sou burro" . mysql_error());
    } else if (resultado($id_jogo, $cod_sel1) < resultado($id_jogo, $cod_sel2)) {
        $query = "update selecoes set pontos=pontos+3 where cod_sel='$cod_sel2'";
        mysql_query($query) or die("sou burro" . mysql_error());
    }
    mysql_close();
}

function set_jogo_terminado($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "update jogos set terminado=1 where id_jogo=$id_jogo";
    mysql_query($query, $ligacao);
}

function atualiza_jogos($id_jogo, $data_jogo, $id_estadio) {
    $ligacao = ligar_base_dados();
    $query = "update jogos j set j.data_jogo='$data_jogo',j.Estadios_id_estadio=$id_estadio where j.id_jogo=$id_jogo'";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;
    if (($resultado) == false) {
        redirect("calendario.php");
    } else {
        $valor_retorno = true;
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function cria_jogos($id_jogo, $data_jogo, $cod_sel1, $cod_sel2, $id_estadio) {
    $ligacao = ligar_base_dados();

    $query = "update jogos j set j.data_jogo='$data_jogo', j.Estadios_id_estadio=$id_estadio where j.id_jogo=$id_jogo";
    $query1 = "insert into selecoesdestacadas  (Selecoes_cod_sel,Jogos_id_jogo, n_golos) values('$cod_sel1',$id_jogo,0)";
    $query2 = "insert into selecoesdestacadas  (Selecoes_cod_sel,Jogos_id_jogo, n_golos) values('$cod_sel2',$id_jogo,0)";
    $resultado = mysql_query($query, $ligacao);
    $resultado1 = mysql_query($query1, $ligacao);
    $resultado2 = mysql_query($query2, $ligacao);

    $valor_retorno = false;
    if (($resultado && $resultado1 && $resultado2) == false) {
        redirect("calendario.php");
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function adiciona_comentario($descricao, $nome) {
    $ligacao = ligar_base_dados();
    $query = "INSERT INTO `comentarios`(descricao, nome, denuncias) VALUES ('$descricao', '$nome',0)";
    $resultado = mysql_query($query, $ligacao) or die('Error: ' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remove_sel_grupo($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "UPDATE selecoes set Grupos_id_grupo = NULL where cod_sel = '$cod_sel'";
    $resultado = mysql_query($query, $ligacao) or die('Error: ' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function edita_dados_utilizador($id, $mail, $data_nasc, $pass, $telemovel, $morada) {
    $ligacao = ligar_base_dados();
    $passNova = mysql_real_escape_string($pass);
    $passEncriptada = md5($passNova);
    $query = "UPDATE utilizadores set mail = '$mail', data_nasc='$data_nasc',pass='$passEncriptada', telemovel=$telemovel, morada='$morada'"
            . "  where id_utilizador = $id";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_descricao_grupo($id_grupo) {
    $ligacao = ligar_base_dados();
    $query = "select descricao from grupos where id_grupo=$id_grupo ";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_assoc($resultado);
    $descricao = $linha['descricao'];
    mysql_close($ligacao);
    return $descricao;
}

function update_grupo($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "update jogos set  Fases_id_fase=1 where id_jogo=$id_jogo";
    mysql_query($query, $ligacao);
}

function get_descricao_grupos() {
    $ligacao = ligar_base_dados();
    $query = "select * from grupos";
    $resultado = mysql_query($query, $ligacao);
    $grupos = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($grupo = mysql_fetch_assoc($resultado)) {
            $grupos[] = $grupo;
        }
        mysql_close($ligacao);
        return $grupos;
    }
}

function jogadorCartoesVermelhos() {
    $ligacao = ligar_base_dados();
    $query = "select j.*, s.pais from Jogadores j, selecoes s where j.Selecoes_cod_sel=s.cod_sel order by n_cart_verm desc";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Jogador com mais cartoes vermelhos</h2>
        <table class="tablePequena">
            <tr>
                <th>Nome</th>
                <th>Numero de cartoes</th>
                <th>País</th>
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {
                $i = mysql_fetch_array($resultado)
                ?>
                <tr>
                    <td><?= $i['nome'] ?></td>
                    <td><?= $i['n_cart_verm'] ?></td>
                    <td><?= $i['pais'] ?></td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>  
    <?php
}

function jogadorCartoesAmarelos() {
    $ligacao = ligar_base_dados();
    $query = "select j.*, s.pais from Jogadores j, selecoes s where j.Selecoes_cod_sel=s.cod_sel order by n_cartoes_amar desc";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Jogador com mais cartoes amarelos</h2>
        <table class="tablePequena">
            <tr>
                <th>Nome</th>
                <th>Numero de cartoes</th>
                <th>País</th>
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {
                $i = mysql_fetch_array($resultado)
                ?>
                <tr>
                    <td><?= $i['nome'] ?></td>
                    <td><?= $i['n_cartoes_amar'] ?></td>
                    <td><?= $i['pais'] ?></td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>  
    <?php
}

function jogoCartoesVermelhos() {
    $ligacao = ligar_base_dados();
    $query = "select j.data_jogo, j.id_jogo, sum(n_cart_verm) as cartoes_jogo from jogos j, cartoes c, jogadores jo where j.id_jogo=c.Jogos_id_jogo and c.Jogadores_id_jogador = jo.id_jogador group by Jogos_id_jogo order by cartoes_jogo desc;;";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Jogos com mais cartões vermelhos</h2>
        <table class="tablePequena">
            <tr>
                <th>Seleção</th>
                <th>Seleção</th> 
                <th>Cartões</th>
                <th>Data</th>
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {

                if ($i = mysql_fetch_array($resultado)) {

                    $id_jogo = $i['id_jogo'];
                    $sel = get_sel($id_jogo);
                    ?>
                    <tr>
                        <td><?= $sel[0] ?></td>
                        <td><?= $sel[1] ?></td>
                        <td><?= $i['cartoes_jogo'] ?></td>
                        <td><?= $i['data_jogo'] ?></td>     
                    </tr>
                    <?php
                } else {
                    
                }
            }
            ?>
        </table>
    </div>
    <?php
}

function estatisticasJogoMaisGolos() {
    $ligacao = ligar_base_dados();
    $query = "select s.Jogos_id_jogo, j.data_jogo, sum(n_golos) as golos_jogo from selecoesdestacadas s, jogos j where j.id_jogo=s.Jogos_id_jogo group by Jogos_id_jogo order by golos_jogo desc;";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Jogo com mais golos</h2>
        <table class="tablePequena">
            <tr>
                <th>Seleção</th>
                <th>Seleção</th> 
                <th>Golos</th>
                <th>Data</th>
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {

                if ($i = mysql_fetch_array($resultado)) {

                    $id_jogo = $i['Jogos_id_jogo'];
                    $sel = get_sel($id_jogo);
                    ?>
                    <tr>
                        <td><?= $sel[0] ?></td>
                        <td><?= $sel[1] ?></td>
                        <td><?= $i['golos_jogo'] ?></td>
                        <td><?= $i['data_jogo'] ?></td>     
                    </tr>
                    <?php
                } else {
                    
                }
            }
            ?>
        </table>
    </div>
    <?php
}

function get_sel($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select pais from selecoesdestacadas, selecoes where Jogos_id_jogo=$id_jogo and Selecoes_cod_sel=cod_sel";
    $resultado = mysql_query($query, $ligacao);
    $selecoes = array();
    while ($linha = mysql_fetch_array($resultado)) {
        $selecoes[] = $linha['pais'];
    }
    return $selecoes;
}

function jogoCartoesAmarelos() {
    $ligacao = ligar_base_dados();
    $query = "select j.data_jogo, j.id_jogo, sum(n_cartoes_amar) as cartoes_jogo from jogos j, cartoes c, jogadores jo where j.id_jogo=c.Jogos_id_jogo and c.Jogadores_id_jogador = jo.id_jogador group by Jogos_id_jogo order by cartoes_jogo desc;";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Jogos com mais cartões amarelos</h2>
        <table class="tablePequena">
            <tr>
                <th>Seleção</th>
                <th>Seleção</th> 
                <th>Cartões</th>
                <th>Data</th>
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {

                if ($i = mysql_fetch_array($resultado)) {

                    $id_jogo = $i['id_jogo'];
                    $sel = get_sel($id_jogo);
                    ?>
                    <tr>
                        <td><?= $sel[0] ?></td>
                        <td><?= $sel[1] ?></td>
                        <td><?= $i['cartoes_jogo'] ?></td>
                        <td><?= $i['data_jogo'] ?></td>     
                    </tr>
                    <?php
                } else {
                    
                }
            }
            ?>
        </table>
    </div>
    <?php
}

function get_grupos() {
    $ligacao = ligar_base_dados();
    $query = "select * from grupos";
    $resultado = mysql_query($query, $ligacao);
    $id_grupos = array();
    $descricao_grupos = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($grupo = mysql_fetch_array($resultado)) {
            $id_grupos[] = $grupo["id_grupo"];
            $descricao_grupos[] = $grupo["descricao"];
        }
    }
    for ($i = 0; $i < count($id_grupos); $i++) {
        ?>

        <div class="tabelasGrupos">
            <table class="tablePequena">
                <caption>
                    <p><?= "$descricao_grupos[$i]" ?></p>
                    <?php if (isset($_SESSION['perfil']) && ($_SESSION['perfil'] == 1)) { ?>
                        <a href="editarGrupos.php?id_grupo=<?= $id_grupos[$i] ?>
                           &descricao_grupo=<?= $descricao_grupos[$i] ?>">
                            <input type="submit" value="editar"></a> <!--é suposto passar que grupo se quer editar e ir para a pagina editar-->
                        <a href="verGrupos.php?remover=<?= $id_grupos[$i] ?>">
                            <input type="submit" value="remover"></a> <!--ver como grupo da su fez, tem um link para a pagina da função-->
                    <?php } ?>
                </caption>
                <tr> 
                    <th> Seleção </th><th> Jogos </th><th> GM </th><th> GS </th><th> DfG </th><th> Pontos</th>
                </tr>
                <?php
                $grupo = get_grupo_ordenado($id_grupos[$i]);
                for ($a = 0; $a < count($grupo); $a++) {
                    $pais = $grupo[$a]['pais'];
                    $golos_marc = $grupo[$a]['golos_marc'];
                    $golos_sofr = $grupo[$a]['golos_sofr'];
                    $dif_golos = $grupo[$a]['dif_golos'];
                    $pontos = $grupo[$a]['pontos'];
                    $cod_sel = $grupo[$a]['cod_sel'];
                    if ($a == 0 || $a == 1) {
                        ?>
                        <tr id="apurados">
                            <td><?= "$pais" ?></td><td><?= "" . contar_jogos_grupo($cod_sel) ?></td>
                            <td><?= "$golos_marc" ?></td><td><?= "$golos_sofr" ?></td><td><?= "$dif_golos" ?></td>
                            <td><?= "$pontos" ?></td>
                        </tr>
                    <?php } else { ?>
                        <tr>
                            <td><?= "$pais" ?></td><td><?= "" . contar_jogos_grupo($cod_sel) ?></td>
                            <td><?= "$golos_marc" ?></td><td><?= "$golos_sofr" ?></td><td><?= "$dif_golos" ?></td>
                            <td><?= "$pontos" ?></td>
                        </tr>
                        <?php
                    }
                }
                ?>
            </table>
        </div>
        <?php
    }
}

function get_grupo_ordenado($id_grupo) {
    $ligacao = ligar_base_dados();
    $query = "select pais, cod_sel,golos_marc,golos_sofr,dif_golos,pontos 
                          from selecoes 
                          where Grupos_id_grupo=$id_grupo
                          order by pontos desc, dif_golos desc , golos_marc desc ";
    $resultado = mysql_query($query, $ligacao);
    $selecoes = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($selecao = mysql_fetch_array($resultado)) {
            $selecoes[] = $selecao;
        }
    }
    return $selecoes;
}

function get_selecoes_by_grupo($id_grupo = NULL) {
    $ligacao = ligar_base_dados();
    if (null == $id_grupo) {
        $query = "select pais, cod_sel from selecoes where Grupos_id_grupo is NULL";
    } else {
        $query = "select pais, cod_sel from selecoes where Grupos_id_grupo=$id_grupo";
    }
    $resultado = mysql_query($query, $ligacao);
    $selecoes = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($selecao = mysql_fetch_assoc($resultado)) {
            $selecoes[] = $selecao;
        }
    }
    mysql_close($ligacao);
    return $selecoes;
}

function contar_jogos_grupo($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select count(*) from selecoesdestacadas a, jogos b where a.Jogos_id_jogo=b.id_jogo and a.Selecoes_cod_sel='$cod_sel' and b.Fases_id_fase='1' and b.terminado=1";
    $resultado = mysql_query($query, $ligacao);

    if ($resultado == false) {
        return 0;
    } else {
        $n_jogos = mysql_fetch_array($resultado);
        return $n_jogos[0];
    }
    mysql_close($ligacao);
}

function regista_selecao($cod, $pais) {
    $ligacao = ligar_base_dados();
    $cod = mysql_real_escape_string($cod);
    $pais = mysql_real_escape_string($pais);

    $query = "INSERT INTO `selecoes`(cod_sel,pais,Fases_id_fase, golos_marc, golos_sofr, dif_golos, pontos) VALUES ('$cod','$pais',1,0,0,0,0)";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remove_jogador($id_jogador) {
    $ligacao = ligar_base_dados();
    $expressao = "DELETE FROM jogadores WHERE id_jogador='$id_jogador'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        echo "<script language=javascript>alert( 'Este jogador já realizou jogos' );</script>";
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remove_elemento_staff($id_staff) {
    $ligacao = ligar_base_dados();
    $expressao = "DELETE FROM staff WHERE id_staff='$id_staff'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_staff_by_sel($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select pais,id_staff, nome, descricao, Funcoes_id_Funcoes from staff, funcoes, selecoes where Selecoes_cod_sel='$cod_sel' and cod_sel='$cod_sel' and id_funcoes=Funcoes_id_funcoes order by Funcoes_id_Funcoes";
    $resultado = mysql_query($query, $ligacao);
    $staff = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($elemento = mysql_fetch_assoc($resultado)) {
            $staff[] = $elemento;
        }
        mysql_close($ligacao);
        return $staff;
    }
}

function get_jogadores_by_sel($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select pais,id_jogador, nome, n_camisola, posicao from jogadores, selecoes where Selecoes_cod_sel='$cod_sel' and cod_sel='$cod_sel' order by n_camisola";
    $resultado = mysql_query($query, $ligacao);
    $jogadores = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($jogador = mysql_fetch_assoc($resultado)) {
            $jogadores[] = $jogador;
        }
        mysql_close($ligacao);
        return $jogadores;
    }
}

function remove_selecao($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "DELETE FROM selecoes WHERE cod_sel='$cod_sel'";
    $valor_retorno = false;
    if ($resultado = mysql_query($query, $ligacao)) {
        $valor_retorno = true;
    } else {
        echo "<script language=javascript>alert( 'Não pode eliminar a seleção! Primeiro remova os seus elementos!' );</script>";
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function get_selecoes_incompletas() {
    $ligacao = ligar_base_dados();
    $query = "select * from selecoes s where(select count(*) from jogadores where cod_sel=Selecoes_cod_sel) <23 "
            . "or not exists(select * from staff st where Funcoes_id_Funcoes=1 and s.cod_sel=st.Selecoes_cod_sel "
            . "and exists(select Selecoes_cod_sel from staff st2 where Funcoes_id_Funcoes=2 and "
            . "st.Selecoes_cod_sel=st2.Selecoes_cod_sel));";
    $resultado = mysql_query($query, $ligacao);
    $cod_selecoes = array();
    $pais_selecoes = array();
    while ($selecao = mysql_fetch_array($resultado)) {
        $cod_selecoes[] = $selecao["cod_sel"];
        $pais_selecoes[] = $selecao["pais"];
    }
    ?>
    <div class="tabelaSelecao">
        <table class="tableGrande">
            <tr> 
                <th> Cod </th>
                <th> Nome </th>
            </tr>
            <?php
            for ($i = 0; $i < count($cod_selecoes); $i++) {
                ?>
                <tr>
                    <td> <?= $cod_selecoes[$i] ?></td>
                    <td> <?= $pais_selecoes[$i] ?></td>
                    <td>
                        <a href="editarSelecao.php?cod_sel=<?= $cod_selecoes[$i] ?> &pais=<?= $pais_selecoes[$i] ?>"><input type="button" value="ver"></a>
                        <a href="selecoes.php?remover=<?= $cod_selecoes[$i] ?>"><input type="button" value="remover"></a>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <?php
}

function getCodSelecao($pais) {
    $ligacao = ligar_base_dados();
    $query = "select cod_sel from selecoes where pais='$pais'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        echo "<script language=javascript>alert( 'A seleção ainda não existe! );</script>";
    } else {
        $selecao = mysql_fetch_assoc($resultado);
    }
    mysql_close($ligacao);
    return $selecao['cod_sel'];
}

function get_selecoes() {
    $ligacao = ligar_base_dados();
    $query = "select * from selecoes";
    $resultado = mysql_query($query, $ligacao);
    $cod_selecoes = array();
    $pais_selecoes = array();
    while ($selecao = mysql_fetch_array($resultado)) {
        $cod_selecoes[] = $selecao["cod_sel"];
        $pais_selecoes[] = $selecao["pais"];
    }
    ?>
    <div class="tabelaSelecao">
        <table class="tableGrande">
            <tr> 
                <th> Cod </th>
                <th> Nome </th>
            </tr>
            <?php
            for ($i = 0; $i < count($cod_selecoes); $i++) {
                ?>
                <tr>
                    <td> <?= $cod_selecoes[$i] ?></td>
                    <td> <?= $pais_selecoes[$i] ?></td>
                    <td>
                        <a href="editarSelecao.php?cod_sel=<?= $cod_selecoes[$i] ?>&pais=<?= $pais_selecoes[$i] ?>"><input type="button" value="ver"></a>
                        <?php if (isset($_SESSION['id']) && $_SESSION['id'] == 1) { ?><a href="selecoes.php?remover=<?= $cod_selecoes[$i] ?>"><input type="button" value="remover"></a>
                        <?php } ?></td>
                </tr>
            <?php } ?>
        </table>
    </div>
    <?php
}

function regista_estadio($nome, $cidade, $lotacao, $latitude, $longitude) {
    $ligacao = ligar_base_dados();
    $nome = mysql_real_escape_string($nome);
    $cidade = mysql_real_escape_string($cidade);
    $lotacao = mysql_real_escape_string($lotacao);
    $latitude = mysql_real_escape_string($latitude);
    $longitude = mysql_real_escape_string($longitude);

    $query = "INSERT INTO `estadios`(nome, cidade,lotacao,latitude,longitude ) VALUES ('$nome', '$cidade','$lotacao','$latitude','$longitude')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function atualiza_estadios($nome, $cidade, $lotacao, $latitude, $longitude, $id_estadio) {
    $ligacao = ligar_base_dados();
    $query = "update estadios set nome='$nome', cidade='$cidade', lotacao=$lotacao, longitude=$longitude, latitude=$latitude where id_estadio=$id_estadio";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remover_estadio($id) {
    $ligacao = ligar_base_dados();
    $expressao = "DELETE FROM estadios WHERE id_estadio='$id'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_estadios_incompletos() {
    $ligacao = ligar_base_dados();
    $query = "select * from estadios where(cidade='' or nome='' or lotacao=0 or latitude=0 or longitude=0)";
    $resultado = mysql_query($query, $ligacao);

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($estadio = mysql_fetch_array($resultado)) {
            $id_estadio = $estadio["id_estadio"];
            $nome_estadio = $estadio["nome"];
            $cidade_estadio = $estadio["cidade"];
            $lotacao_estadio = $estadio["lotacao"];
            $latitude_estadio = $estadio["latitude"];
            $longitude_estadio = $estadio["longitude"];
            ?>
            <h1>Estádios Incompletos</h1>
            <div  class="tabelasGrupos">
                <table class="tablePequena">
                    <caption>
                        <?= "$nome_estadio" ?>
                        <a href="editarEstadios.php?id_estadio=<?= $id_estadio ?>&nome=<?= $nome_estadio ?>&cidade=<?= $cidade_estadio ?>
                           &lotacao=<?= $lotacao_estadio ?>&latitude=<?= $latitude_estadio ?>&longitude=<?= $longitude_estadio ?>"><input type="submit" value="editar"></a> 
                        <a href="verEstadios.php?remover= <?= $id_estadio ?> "><input type="button" value="remover"> </a>
                    </caption>
                    <tr> 
                        <th> Cidade </th>
                        <th> Lotação </th>
                        <th> Latitude</th>
                        <th> Longitude</th>
                    </tr>
                    <tr>
                        <td><?= $cidade_estadio ?></td>
                        <td><?= $lotacao_estadio ?></td>
                        <td><?= $latitude_estadio ?></td>
                        <td><?= $longitude_estadio ?></td>
                    </tr>
                </table>
            </div>

            <?php
        }mysql_close($ligacao);
    }
}

function get_nome_estadios() {
    $ligacao = ligar_base_dados();
    $query = "select nome, id_estadio from estadios";
    $resultado = mysql_query($query, $ligacao);
    $estadios = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($estadio = mysql_fetch_assoc($resultado)) {
            $estadios[] = $estadio;
        }
    }
    mysql_close($ligacao);
    return $estadios;
}

function get_estadios() {

    $ligacao = ligar_base_dados();
    $query = "select * from estadios";
    $resultado = mysql_query($query, $ligacao);

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($estadio = mysql_fetch_array($resultado)) {
            $id_estadio = $estadio["id_estadio"];
            $nome_estadio = $estadio["nome"];
            $cidade_estadio = $estadio["cidade"];
            $lotacao_estadio = $estadio["lotacao"];
            $latitude_estadio = $estadio["latitude"];
            $longitude_estadio = $estadio["longitude"];
            ?>
            <div  class="tabelasGrupos">
                <table class="tablePequena">
                    <caption>
                        <?= "$nome_estadio" ?>
                        <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 2) { ?><a href="editarEstadios.php?id_estadio=<?= $id_estadio ?>&nome=<?= $nome_estadio ?>&cidade=<?= $cidade_estadio ?>
                               &lotacao=<?= $lotacao_estadio ?>&latitude=<?= $latitude_estadio ?>&longitude=<?= $longitude_estadio ?>"><input type="submit" value="editar"></a> 
                            <a href="verEstadios.php?remover= <?= $id_estadio ?> "><input type="button" value="remover"> </a> <?php } ?>
                    </caption>
                    <tr>
                        <th> Cidade </th>
                        <th> Lotação </th>
                        <th> Latitude</th>
                        <th> Longitude</th>
                    </tr>
                    <tr>
                        <td><?= $cidade_estadio ?></td>
                        <td><?= $lotacao_estadio ?></td>
                        <td><?= $latitude_estadio ?></td>
                        <td><?= $longitude_estadio ?></td>
                    </tr>
                </table>
            </div>

            <?php
        }mysql_close($ligacao);
    }
}

function redirect($url) {
    header("Location: $url");
}

function get_tipos_utilizador() {
    $ligacao = ligar_base_dados();
    $query = "select descricao from perfis";
    $resultado = mysql_query($query, $ligacao);
    $tipos = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($tipo = mysql_fetch_assoc($resultado)) {
            $tipos[] = $tipo["descricao"];
        }
    }
    mysql_close($ligacao);
    return $tipos;
}

function actualiza_jogos_provisorio($id_jogo, $data_jogo) {
    $ligacao = ligar_base_dados();
    $query = "update jogos set j.data_jogo='$data_jogo'";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;
    if (($resultado && $resultado1) == false) {
        redirect("calendario.php");
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remover_jogo_provisorio($id_jogo) {
    $ligacao = ligar_base_dados();
    $expressao = "DELETE from jogos WHERE id_jogo='$id_jogo'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_fases() {
    $ligacao = ligar_base_dados();
    $query = "select id_fase,descricao from fases";
    $resultado = mysql_query($query, $ligacao);
    $fases = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($fase = mysql_fetch_assoc($resultado)) {
            $fases[] = $fase;
        }
    }
    mysql_close($ligacao);
    return $fases;
}

function get_nome_selecoes() {
    $ligacao = ligar_base_dados();
    $query = "select pais, cod_sel from selecoes";
    $resultado = mysql_query($query, $ligacao);
    $selecoes = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($selecao = mysql_fetch_assoc($resultado)) {
            $selecoes[] = $selecao;
        }
    }
    mysql_close($ligacao);
    return $selecoes;
}

function get_staff($id_staff) {
    $ligacao = ligar_base_dados();
    $query = "select * from staff,selecoes,funcoes where id_staff='$id_staff' and Funcoes_id_Funcoes=id_Funcoes and Selecoes_cod_sel=cod_sel";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $staff = mysql_fetch_array($resultado);
    }
    return $staff;
}

function get_id_funcao($descricao) {
    $ligacao = ligar_base_dados();
    $query = "select id_Funcoes from funcoes where descricao='$descricao'";
    $resultado = mysql_query($query, $ligacao);
    $ids = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($id = mysql_fetch_assoc($resultado)) {
            $ids[] = $id["id_Funcoes"];
        }
    }
    mysql_close($ligacao);
    return $ids[0];
}

function editar_staff($id_staff, $data_nasc, $sexo, $g_sanguineo, $id_funcao) {
    $ligacao = ligar_base_dados();
    $query = "update staff set data_nasc='$data_nasc',sexo='$sexo', g_sanguineo='$g_sanguineo', Funcoes_id_Funcoes='$id_funcao' where id_staff='$id_staff'";

    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_funcoes() {
    $ligacao = ligar_base_dados();
    $query = "select descricao from funcoes";
    $resultado = mysql_query($query, $ligacao);
    $funcoes = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        while ($funcao = mysql_fetch_assoc($resultado)) {
            $funcoes[] = $funcao["descricao"];
        }
    }
    mysql_close($ligacao);
    return $funcoes;
}

function regista_elemento($nome, $data_nasc, $sexo, $g_sanguineo, $cod_sel, $funcao) {
    $ligacao = ligar_base_dados();
    $nome = mysql_real_escape_string($nome);
    $data_nasc = mysql_real_escape_string($data_nasc);
    $sexo = mysql_real_escape_string($sexo);
    $g_sanguineo = mysql_real_escape_string($g_sanguineo);
    $cod_sel = mysql_real_escape_string($cod_sel);
    $funcao = mysql_real_escape_string($funcao);

    $query = "INSERT INTO `staff`(nome, data_nasc,sexo,g_sanguineo,Selecoes_cod_sel, Funcoes_id_Funcoes) VALUES ('$nome', '$data_nasc','$sexo','$g_sanguineo','$cod_sel', '$funcao')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_jogador($id_jogador) {
    $ligacao = ligar_base_dados();
    $query = "select * from jogadores,selecoes where id_jogador='$id_jogador' and Selecoes_cod_sel=cod_sel";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $jogador = mysql_fetch_array($resultado);
    }
    return $jogador;
}

function editar_jogador($id_jogador, $posicao, $data_nasc, $g_sanguineo, $peso, $altura, $n_camisola, $n_intern) {
    $ligacao = ligar_base_dados();
    $query = "update jogadores set posicao='$posicao', data_nasc='$data_nasc', g_sanguineo='$g_sanguineo',peso=$peso, altura=$altura, n_camisola=$n_camisola, n_intern=$n_intern where id_jogador='$id_jogador'";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function existe_utilizador($email) {
    $ligacao = ligar_base_dados();
    $query = "select count(mail) as cona from utilizadores where mail='$email'";
    $resultado = mysql_query($query, $ligacao);
    $count = mysql_fetch_array($resultado);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $count['cona'];
    }
    mysql_close($ligacao);
    return $count['cona'];
}

function regista_utilizador($nome, $mail, $pais, $data_nasc, $telemovel, $morada, $tipo, $n_login) {
    $ligacao = ligar_base_dados();
    $pass = geraPassword();
    $passEncriptada = md5($pass);
    $nome = mysql_real_escape_string($nome);
    $mail = mysql_real_escape_string($mail);
    $pais = mysql_real_escape_string($pais);
    $data_nasc = mysql_real_escape_string($data_nasc);
    $morada = mysql_real_escape_string($morada);

    $query = "INSERT INTO `utilizadores`(nome,mail,Selecoes_cod_sel,data_nasc,pass,telemovel,morada,Perfis_id_perfil, n_login)"
            . " VALUES ('$nome','$mail','$pais','$data_nasc','$passEncriptada',$telemovel,'$morada',$tipo, $n_login)";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
        $assunto = "Password de acesso";
        $mensagem = utf8_decode("Olá $nome! O seu registo foi efetuado com sucesso!</br> A sua password de acesso é <b> $pass </b> ."
                . "Deve aceder ao site e alterar a sua password. <br/>
Para navegar aceda ao link:  
<a href='http://localhost/fifaWC2018/homePage.php'>Login</a> </br> Cumprimentos");
        enviarEmail($assunto, $mensagem, $mail);
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function regista_jogador($nome, $posicao, $data_nasc, $g_sanguineo, $peso, $altura, $n_camisola, $n_intern, $cod_sel) {
    $ligacao = ligar_base_dados();
    $nome = mysql_real_escape_string($nome);
    $posicao = mysql_real_escape_string($posicao);
    $data_nasc = mysql_real_escape_string($data_nasc);
    $g_sanguineo = mysql_real_escape_string($g_sanguineo);
    $peso = mysql_real_escape_string($peso);
    $altura = mysql_real_escape_string($altura);
    $n_camisola = mysql_real_escape_string($n_camisola);
    $n_intern = mysql_real_escape_string($n_intern);
    $cod_sel = mysql_real_escape_string($cod_sel);

    $query = "INSERT INTO `jogadores`(nome, posicao,data_nasc,g_sanguineo,peso, altura, n_camisola, n_intern, Selecoes_cod_sel,golos,n_golos_marc,n_cartoes_amar,n_cart_verm) VALUES ('$nome','$posicao','$data_nasc','$g_sanguineo','$peso', '$altura', '$n_camisola', '$n_intern','$cod_sel',0,0,0)";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function atualiza($id_utilizador) {
    $ligacao = ligar_base_dados();
    $expressao = "UPDATE utilizadores set n_login=n_login+1 WHERE id_utilizador='$id_utilizador'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_n_login($id) {
    $ligacao = ligar_base_dados();
    $query = "SELECT n_login FROM utilizadores WHERE id_utilizador='$id'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $n_login = mysql_fetch_array($resultado);
    }
    return $n_login;
}

function valida_utilizador($mail, $pass) {
    $mail = mysql_real_escape_string($mail);
    $pass1 = md5($pass);
    $ligacao = ligar_base_dados();
    $expressao = "SELECT * FROM utilizadores WHERE mail='$mail' AND pass='$pass1'";

    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;


    if (mysql_num_rows($resultado) === 1) {
        $dados = mysql_fetch_array($resultado);
        if ($dados['pass'] == $pass1) {
            $valor_retorno = $dados;
        }
    }

    mysql_free_result($resultado);
    mysql_close($ligacao);

    return $valor_retorno;
}

function estatisticasMelhorJogador() {
    $ligacao = ligar_base_dados();
    $query = "select * from Jogadores order by n_golos_Marc desc";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    ?>
    <div class="tabelasGrupos">
        <h2>Melhor marcador</h2>
        <table class="tablePequena">
            <tr>
                <th>Nome</th>
                <th>Golos</th>
                <th>Nacionalidade</th>
            </tr>
            <?php
            for ($x = 1; $x <= 5; $x++) {
                $i = mysql_fetch_array($resultado);
                ?>
                <tr>
                    <td><?= $i['nome'] ?></td>
                    <td><?= $i['n_golos_Marc'] ?></td>
                    <td><?= $i['Selecoes_cod_sel'] ?></td>

                </tr>
                <?php
            }
            ?>
        </table>
    </div>
    <?php
}

function estatisticasMelhorDefesa() {
    $ligacao = ligar_base_dados();
    $query = "select * from Selecoes order by golos_sofr asc";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Seleção com melhor Defesa</h2>
        <table class="tablePequena">
            <tr>
                <th>Pais</th>
                <th>Golos sofridos</th>
            </tr>
            <?php
            for ($x = 1; $x <= 4; $x++) {
                $i = mysql_fetch_array($resultado)
                ?>
                <tr>
                    <td><?= $i['pais'] ?></td>
                    <td><?= $i['golos_sofr'] ?></td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
    <?php
}

function estatisticasMelhorAtaque() {

    $ligacao = ligar_base_dados();
    $query = "select * from Selecoes order by golos_marc desc";
    $resultado = mysql_query($query, $ligacao);
    ?>
    <div class="tabelasGrupos">
        <h2>Seleção com melhor ataque</h2>
        <table class="tablePequena">
            <tr>
                <th>Pais</th>
                <th>Golos marcados</th>                                
            </tr> 
            <?php
            for ($x = 1; $x < 5; $x++) {
                $i = mysql_fetch_array($resultado)
                ?>
                <tr>
                    <td><?= $i['pais'] ?></td>
                    <td><?= $i['golos_marc'] ?></td>     
                </tr>
                <?php
            }
            ?>
        </table>
    </div>  
    <?php
}

function get_evento() {
    $ligacao = ligar_base_dados();
    $query = "Select * from evento";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        $valor_retorno = null;
    } else {
        while ($linha = mysql_fetch_array($resultado)) {

            $valor_retorno[] = $linha['data_inicio'];
            $valor_retorno[] = $linha['data_fim'];
        }
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function data_evento($data_inicio, $data_fim) {
    $ligacao = ligar_base_dados();
    $apagar = "Delete from evento";
    mysql_query($apagar, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $query = "insert into evento (data_inicio,data_fim) values('$data_inicio','$data_fim')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remove_arbitro($id_arbitro) {
    $ligacao = ligar_base_dados();
    $query = "DELETE FROM Arbitros WHERE id_arbitro='$id_arbitro'";
    $valor_retorno = false;
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_dados_utilizador($id) {
    $ligacao = ligar_base_dados();
    $query = "select * from utilizadores where id_utilizador='$id'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $dados = mysql_fetch_array($resultado);
    }
    return $dados;
}

function geraPassword() {
    $pass = "";
    $nova_pass = "";
    for ($i = 1; $i <= 8; $i++) {
        $pass = chr(rand(65, 90));
        $nova_pass = $nova_pass . $pass;
    }
    return $nova_pass;
}

function get_todos_arbitros() {
    $ligacao = ligar_base_dados();
    $query = "select * from Arbitros";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $arbitros = array();
    while ($arbitro = mysql_fetch_array($resultado)) {
        $arbitros[] = $arbitro;
    }
    mysql_close($ligacao);
    return $arbitros;
}

function adiciona_arbitros($id_jogo, $funcao, $id_arbitro) {
    $ligacao = ligar_base_dados();
    $query = "Insert into arbitrosDestacados (Jogos_id_jogo,TiposArbitro_id_tipo,Arbitros_id_arbitro) values ($id_jogo,$funcao,$id_arbitro)";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        echo "<script language=javascript>alert( 'Este àrbitro já está destacado!' );</script>";
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_arbitros_destacados($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "Select nome,descricao,nacionalidade from arbitrosDestacados,arbitros,tiposarbitro where Jogos_id_jogo=$id_jogo and Arbitros_id_arbitro=id_arbitro and TiposArbitro_id_tipo=id_tipo";
    $resultado = mysql_query($query, $ligacao);
    $arbitrosDestacados = array();
    while ($arbitro = mysql_fetch_assoc($resultado)) {
        $arbitrosDestacados[] = $arbitro;
    }
    mysql_close($ligacao);
    return $arbitrosDestacados;
}

function get_arbitros() {
    $ligacao = ligar_base_dados();
    $query = "select * from Arbitros";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $arbitros = array();
    ?>
    <div class="tabelaSelecao">
        <table class="tableGrande">
            <tr>
                <th>Nome</th>
                <th>Data nascimento</th>
                <th>Nacionalidade</th>
            </tr>
            <?php
            while ($arbitros = mysql_fetch_assoc($resultado)) {
                $id = $arbitros['id_arbitro'];
                ?>
                <tr>
                    <td><?= $arbitros ['nome'] ?></td>
                    <td><?= $arbitros ['data_nasc'] ?></td>
                    <td><?= $arbitros ['nacionalidade'] ?></td>
                    <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?><td><a href="editarArbitros.php?id_arbitro=<?= $id ?> &nome=<?= $arbitros ['nome'] ?>&data_nasc=<?= $arbitros ['data_nasc'] ?> &nacionalidade=<?= $arbitros ['nacionalidade'] ?> "><input type="button" name="editar" value="editar"></a></td>
                        <td><a href="verArbitros.php?remover= <?= $id ?> "><input type="button" value="remover"> </a></td><?php } ?> 
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
    <?php
}

function get_n_golos_by_cod_sel($cod_sel, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select s.n_golos 
            from selecoesdestacadas s
	    where s.Jogos_id_jogo=$id_jogo
		and s.Selecoes_cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $ngolos = $linha["n_golos"];
    return $ngolos;
}

function adiciona_golos_sel($cod_sel, $id_jogo) {
    $ligacao = ligar_base_dados();
    $ngolos = get_n_golos_by_cod_sel($cod_sel, $id_jogo);
    $query = "update selecoesdestacadas s
              set s.n_golos=($ngolos+1)
              where s.Selecoes_cod_sel='$cod_sel'
                and s.Jogos_id_jogo=$id_jogo";
    mysql_query($query, $ligacao);
}

function verificar_sel_jogador($id_jogador, $cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select j.Selecoes_cod_sel 
            from jogadores j
	    where j.id_jogador=$id_jogador";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $sel = $linha["Selecoes_cod_sel"];
    if ($sel == $cod_sel) {
        $valor_retorno = true;
    } else {
        $valor_retorno = false;
    }
    return $valor_retorno;
}

function get_golos_sofr($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select golos_sofr from selecoes where cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $golos_sofr = $linha['golos_sofr'];
    return $golos_sofr;
}

function get_golos_mar($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select golos_marc from selecoes where cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $golos_marc = $linha['golos_marc'];
    return $golos_marc;
}

function golos_marc($cod_sel) {
    $ligacao = ligar_base_dados();
    $golos_marc = get_golos_mar($cod_sel);
    $golos_marc++;
    $query = "update selecoes set golos_marc=$golos_marc where cod_sel='$cod_sel'";
    mysql_query($query, $ligacao);
}

function get_golos_mar_jog($id_jogador) {
    $ligacao = ligar_base_dados();
    $query = "select n_golos_marc from jogadores where id_jogador=$id_jogador";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $golos_marc = $linha['n_golos_marc'];
    return $golos_marc;
}

function golos_marc_jog($id_jogador) {
    $ligacao = ligar_base_dados();
    $golos_marc = get_golos_mar_jog($id_jogador);
    $golos_marc++;
    $query = "update jogadores set n_golos_marc=$golos_marc where id_jogador='$id_jogador'";
    mysql_query($query, $ligacao);
}

function atribuir_golos($minuto, $autogolo, $id_jogo, $id_jogador, $cod_sel1, $cod_sel2) {
    $ligacao = ligar_base_dados();
    $query = "INSERT INTO `golos` (`minuto`, `autogolo`, `Jogos_id_jogo`, `Jogadores_id_jogador`) VALUES ($minuto, $autogolo, $id_jogo, $id_jogador)";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;
    if (($autogolo == false) && (verificar_sel_jogador($id_jogador, $cod_sel1))) {
        adiciona_golos_sel($cod_sel1, $id_jogo);
        golos_marc($cod_sel1);
        golos_marc_jog($id_jogador);
        golos_sofr($cod_sel2);
    } else if (($autogolo == false) && (verificar_sel_jogador($id_jogador, $cod_sel2))) {
        adiciona_golos_sel($cod_sel2, $id_jogo);
        golos_marc($cod_sel2);
        golos_marc_jog($id_jogador);
        golos_sofr($cod_sel2);
    } else if (($autogolo) && (verificar_sel_jogador($id_jogador, $cod_sel1))) {
        adiciona_golos_sel($cod_sel2, $id_jogo);
        golos_marc($cod_sel2);
        golos_sofr($cod_sel1);
    } else if (($autogolo) && (verificar_sel_jogador($id_jogador, $cod_sel2))) {
        adiciona_golos_sel($cod_sel1, $id_jogo);
        golos_marc($cod_sel1);
        golos_sofr($cod_sel2);
    }
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }
    return $valor_retorno;
}

function get_golos($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select nome, minuto, autogolo,pais from jogadores, golos,selecoes where Jogos_id_jogo=$id_jogo and id_jogador=Jogadores_id_jogador and Selecoes_cod_sel=cod_sel order by minuto";
    $resultado = mysql_query($query, $ligacao);
    $golos = array();
    if ($resultado == false) {
        return false;
    } else {
        while ($golo = mysql_fetch_assoc($resultado)) {
            $golos[] = $golo;
        }
        return $golos;
    }
    mysql_close($ligacao);
}

function get_jogadores_uti_by_cod_sel($cod_sel, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select j.nome, j.id_jogador, j.n_camisola from jogadores j, jogadoresutilizados x where j.Selecoes_cod_sel='$cod_sel' and x.Jogos_id_jogo=$id_jogo and j.id_jogador=x.Jogadores_id_jogador";
    $resultado = mysql_query($query, $ligacao);
    $jogadores = array();
    if ($resultado == false) {

        return false;
    } else {
        while ($jogador = mysql_fetch_assoc($resultado)) {
            $jogadores[] = $jogador;
        }
        return $jogadores;
    }
    mysql_close($ligacao);
}

function alteraPass($pass, $id) {
    $ligacao = ligar_base_dados();
    $passEncript = md5($pass);
    $query = "UPDATE utilizadores set pass='$passEncript' where id_utilizador = $id";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_comentarios() {
    $ligacao = ligar_base_dados();
    $query = "select * from comentarios";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    ?>
    <div style="margin-left: 50%;margin-top: -150px">
        <table class="tablePequena">
            <tr>
                <th>Nome</th>
                <th>Comentário</th>
            </tr>
            <?php
            while ($comentarios = mysql_fetch_assoc($resultado)) {
                ?><tr>
                    <td><?= $comentarios['nome'] ?></td>
                    <td><?= $comentarios ['descricao'] ?></td>
                    <td><a href="comentarios.php?denuncia=<?= $comentarios ['id_comentario'] ?>"><input type="button" value="Denunciar"></a></td>
                </tr>
            <?php }
            ?>
        </table>
    </div><?php
}

function get_denuncias() {
    $ligacao = ligar_base_dados();
    $query = "select * from comentarios where denuncias!=0";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    ?>
    <div style="margin-left: 10%;">
        <table class="tablePequena">
            <tr>
                <th>Nome</th>
                <th>Comentário</th>
            </tr>
            <?php
            while ($comentarios = mysql_fetch_assoc($resultado)) {
                ?><tr>
                    <td><?= $comentarios['nome'] ?></td>
                    <td><?= $comentarios ['descricao'] ?></td>
                    <td><a href="comentarios.php?remover=<?= $comentarios ['id_comentario'] ?>"><input type="button" value="Remover"></a></td>
                </tr>
            <?php }
            ?>
        </table>
    </div><?php
}

function get_id_jogo($cod_sel, $fase) {
    $ligacao = ligar_base_dados();
    $query = "select j.id_jogo from selecoesdestacadas s, jogos j where s.Selecoes_cod_sel='$cod_sel' and j.Fases_id_fase=$fase and s.Jogos_id_jogo=j.id_jogo";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $id_jogo = true;
    if ($resultado == false) {
        $id_jogo = null;
    } else {
        $linha = mysql_fetch_array($resultado);
        $id_jogo = $linha['id_jogo'];
    }
    mysql_close($ligacao);
    return $id_jogo;
}

function get_fase($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select Fases_id_fase from selecoes where cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $linha = mysql_fetch_assoc($resultado);
        $fase = $linha['Fases_id_fase'];
    }
    mysql_close($ligacao);
    return $fase;
}

function get_fase_data_jogo($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select fase,data_jogo from jogos,fases where id_jogo=$id_jogo and Fases_id_fase=id_fase;";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $linha = mysql_fetch_assoc($resultado);
    }
    mysql_close($ligacao);
    return $linha;
}

function get_estadio_jogo($id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "select nome from jogos,estadios where id_jogo=$id_jogo and Estadios_id_estadio=id_estadio";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $linha = mysql_fetch_assoc($resultado);
    }
    mysql_close($ligacao);
    return $linha;
}

function cria_eliminatorias($cod_sel, $id_fase) {
    $ligacao = ligar_base_dados();
    $query = "insert into jogos (Fases_id_fase, terminado) values($id_fase,0)";
    mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $query1 = "select id_jogo from jogos order by id_jogo desc";
    $jogos = array();
    $resultado = mysql_query($query1, $ligacao) or die('Error :' . \mysql_error($ligacao));
    while ($linha = mysql_fetch_array($resultado)) {
        $jogos[] = $linha['id_jogo'];
    }
    $id_jogo = $jogos[0];
    $query2 = "insert into selecoesdestacadas (Selecoes_cod_sel,Jogos_id_jogo, n_golos) values('$cod_sel',$id_jogo,0)";
    mysql_query($query2, $ligacao) or die('Error :' . \mysql_error($ligacao));
    mysql_close();
}

function set_fase($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "update selecoes set Fases_id_fase=Fases_id_fase+1 where cod_sel='$cod_sel' ";
    mysql_query($query, $ligacao) or die('asd :' . mysql_error());
    mysql_close();
}

function update_jo($cod_sel, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "insert into selecoesdestacadas (Selecoes_cod_sel,Jogos_id_jogo, n_golos) values('$cod_sel',$id_jogo,0)";
    mysql_query($query, $ligacao) or die('asd :' . mysql_error());
}

function enviarEmail($mailsubject, $mailbody, $receiveremail) {

//    require("class.phpmailer.php");
    require_once 'class.phpmailer.php';

    $mail = new PHPMailer();
    $mail->IsSMTP();                    // meter o mailer a usar SMTP
    $mail->charSet = "UTF-8";
    $mail->Host = "smtp.sapo.pt";

    $mail->SMTPAuth = true;              // ligar a autenticacao do SMTP

    $mail->Username = "fifawc2018@sapo.pt";     // SMTP username
    $mail->Password = "FIFAWC2018";     // SMTP password

    $mail->From = "fifawc2018@sapo.pt";
    $mail->FromName = "fifawc2018";          // de
    $mail->WordWrap = 50;
    $mail->IsHTML = (true);

    $mail->MsgHTML('A sua confirmaçao foi aprovada:');
    $mail->Subject = $mailsubject;
    $mail->Body = $mailbody;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $MultiEmail = explode(" ; ", $receiveremail);
    foreach ($MultiEmail as $MultiEmails) {
        $mail->AddAddress($MultiEmails);
    }
    $retcode = false;
    if (!$mail->Send()) {
        echo $mail->ErrorInfo; // mostra erro
        $retcode = $mail->ErrorInfo;
    } else {
        $retcode = true;
    }
    return $retcode; // return 
}

function remover_utilizador($id) {
    $ligacao = ligar_base_dados();
    $expressao = "delete from utilizadores where id_utilizador=$id";
    mysql_query($expressao, $ligacao);
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function remover_arbitros($id) {
    $ligacao = ligar_base_dados();
    $expressao = "DELETE from ArbitrosDestacados WHERE Arbitros_id_arbitro =$id";
    mysql_query($expressao, $ligacao);
    $expressao = "DELETE FROM arbitros WHERE id_arbitro='$id'";
    $resultado = mysql_query($expressao, $ligacao);
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function atualiza_arbitros($nome, $data_nasc, $nacionalidade, $id) {
    $ligacao = ligar_base_dados();
    $query = "update Arbitros set nome='$nome',data_nasc='$data_nasc',nacionalidade='$nacionalidade' where id_arbitro='$id'";
    $resultado = mysql_query($query, $ligacao);
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function regista_arbitro($nome, $data_nasc, $nac) {
    $ligacao = ligar_base_dados();
    $nome = mysql_real_escape_string($nome);
    $data_nasc = mysql_real_escape_string($data_nasc);
    $nac = mysql_real_escape_string($nac);

    $query = "INSERT INTO `Arbitros`(nome,data_nasc,nacionalidade)"
            . " VALUES ('$nome','$data_nasc','$nac')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function regista_jogo($data_jogo) {
    $ligacao = ligar_base_dados();
    $data_jogo = mysql_real_escape_string($data_jogo);
    $query = "INSERT INTO `Jogos`(data_jogo) VALUES ('$data_jogo')";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function get_n_intern($id_jogador) {
    $ligacao = ligar_base_dados();
    $query = "select n_intern from jogadores where id_jogador=$id_jogador";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $n_intern = $linha['n_intern'];
    return $n_intern;
}

function resultado($id_jogo, $cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select n_golos from selecoesdestacadas where Selecoes_cod_sel='$cod_sel' and Jogos_id_jogo=$id_jogo";
    $resultado = mysql_query($query, $ligacao);
    $linha = mysql_fetch_array($resultado);
    $n_golos = $linha['n_golos'];
    return $n_golos;
}

function atribuir_cartoes($minuto, $id_jogador, $vermelho, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "INSERT INTO `cartoes` (`minuto`, `vermelho`, `Jogadores_id_jogador`, `Jogos_id_jogo`) VALUES ($minuto, $vermelho, $id_jogador, $id_jogo)";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    if ($vermelho == false) {
        $query = "update jogadores set n_cartoes_amar=n_cartoes_amar+1 where id_jogador=$id_jogador";
        mysql_query($query, $ligacao);
    } else {
        $query = "update jogadores set n_cart_verm=n_cart_verm+1 where id_jogador=$id_jogador";
        mysql_query($query, $ligacao);
        removerJogadorDoJogo($id_jogador, $id_jogo);
    }
    $valor_retorno = false;

    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    return $valor_retorno;
}

function jogador_utilizado($id_jogador, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "INSERT INTO `fifawc2018`.`jogadoresutilizados` (`Jogadores_id_jogador`, `Jogos_id_jogo`) VALUES ($id_jogador, $id_jogo)";
    $resultado = mysql_query($query, $ligacao);
    $n_intern = get_n_intern($id_jogador);
    $n_intern++;
    $query = "update jogadores set n_intern=$n_intern where id_jogador=$id_jogador";
    $resultado = mysql_query($query, $ligacao);
    if ($resultado == false) {
        die('Error dsxvsdx :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function nCartoesAmarelos($id_jogo, $id_jogador) {
    $ligacao = ligar_base_dados();
    $query = "select jo.id_jogador, j.id_jogo, sum(n_cartoes_amar) as cartoes_amarelos from jogos j, cartoes c, jogadores jo where j.id_jogo=c.Jogos_id_jogo and c.Jogadores_id_jogador = jo.id_jogador and j.id_jogo=$id_jogo and jo.id_jogador=$id_jogador";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $i = mysql_fetch_array($resultado);
    return $i['cartoes_amarelos'];
}

function cartoesVermelhos($id_jogador, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "update jogadores j, cartoes c set j.n_cartoes_amar = n_cartoes_amar -2, j.n_cart_verm= n_cart_verm +1 where j.id_jogador = $id_jogador and c.Jogos_id_jogo = $id_jogo;";
    mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    removerJogadorDoJogo($id_jogador, $id_jogo);
}

function removerJogadorDoJogo($id_jogador, $id_jogo) {
    $ligacao = ligar_base_dados();
    $query = "delete from jogadoresutilizados where Jogadores_id_jogador= $id_jogador and Jogos_id_jogo = $id_jogo";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {

        $valor_retorno = true;
    }

    mysql_close($ligacao);
    return $valor_retorno;
}

function nJogadores($cod_selecao) {
    $ligacao = ligar_base_dados();
    $query = "select count(*) from jogadores where Selecoes_cod_sel ='$cod_selecao'";
    $resultado = mysql_query($query, $ligacao);
    $i = mysql_fetch_array($resultado);
    return $i[0];
}

function nGrupos($id_grupo) {
    $ligacao = ligar_base_dados();
    $query = "select count(*) from selecoes where Grupos_id_grupo =$id_grupo";
    $resultado = mysql_query($query, $ligacao);
    $i = mysql_fetch_array($resultado);
    return $i[0];
}

function repetirJogador($cod_sel) {
    $ligacao = ligar_base_dados();
    $query = "select n_camisola from jogadores where Selecoes_cod_sel='$cod_sel'";
    $resultado = mysql_query($query, $ligacao);
    $jogador = mysql_fetch_array($resultado);
    return $jogador;
}

function limiteGrupo() {
    $ligacao = ligar_base_dados();
    $query = "select count(*) from grupos";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $i = mysql_fetch_array($resultado);
    return $i[0];
}

function verificarSelecoes($id_sel1, $id_sel2) {
    $ligacao = ligar_base_dados();
    $query1 = "select Jogos_id_jogo from selecoesdestacadas s, jogos j where s.Selecoes_cod_sel='$id_sel1' and j.Fases_id_fase = 1 and j.id_jogo=s.Jogos_id_jogo";
    $resultado = mysql_query($query1, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $jogos_sel1 = array();
    while ($jogo_sel1 = mysql_fetch_array($resultado)) {
        $jogos_sel1[] = $jogo_sel1;
    }
    $query2 = "select Jogos_id_jogo from selecoesdestacadas s, jogos j where s.Selecoes_cod_sel='$id_sel2' and j.Fases_id_fase = 1 and j.id_jogo=s.Jogos_id_jogo";
    $resultado2 = mysql_query($query2, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $jogos_sel2 = array();
    while ($jogo_sel2 = mysql_fetch_array($resultado2)) {
        $jogos_sel2[] = $jogo_sel2;
    }
    $valor_retorno = false;
    for ($i = 0; $i < count($jogos_sel1); $i++) {
        $jogo = $jogos_sel1[$i];
        if (in_array($jogo, $jogos_sel2)) {
            $valor_retorno = true;
        }
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function recuperarPass($mail) {
    $ligacao = ligar_base_dados();
    $mail = mysql_real_escape_string($mail);
    $novaPass = geraPassword();
    $passEncrypt = md5($novaPass);
    $query1 = "Select id_utilizador, nome from utilizadores where mail='$mail'";
    $result = mysql_query($query1, $ligacao);
    $id_utilizador = mysql_fetch_array($result);
    if ($id_utilizador == false) {
        echo "<script language=javascript>alert( 'Não existe nenhum utilizador com esse e-mail!!' );</script>";
    } else {
        $id = $id_utilizador['id_utilizador'];
        $nome = $id_utilizador['nome'];
        $query = "update utilizadores set pass='$passEncrypt',n_login=0 where mail='$id'";
        $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
        $valor_retorno = false;
        if ($resultado == false) {
            die('Error :' . \mysql_error($ligacao));
        } else {
            $valor_retorno = true;
            $assunto = "Nova Password";
            $mensagem = utf8_decode("Ola $nome ! A sua password foi alterada com sucesso!</br> A nova password de acesso é <b> $novaPass </b> ."
                    . "Deve aceder ao site e alterar a sua password. <br/>
Para navegar aceda ao link:  
<a href='http://localhost/fifaWC2018/homePage.php'>Login</a> </br> Cumprimentos");
            enviarEmail($assunto, $mensagem, $mail);
            echo "<script language=javascript>alert( 'A nova pass foi enviada. Verifique o seu e-mail!!' );</script>";
        }
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function denunciar($id_comentario) {
    $ligacao = ligar_base_dados();
    $query = "UPDATE comentarios set denuncias=denuncias+1 where id_comentario='$id_comentario'";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }mysql_close($ligacao);
    return $valor_retorno;
}

function remover_comentario($id) {
    $ligacao = ligar_base_dados();
    $query = "DELETE from comentarios where id_comentario='$id'";
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }mysql_close($ligacao);
    return $valor_retorno;
}

function mail_jogo($id_jogo, $cod_sel1, $cod_sel2) {
    $selecoes = get_sel($id_jogo);
    $sel1 = $selecoes[0];
    $sel2 = $selecoes[1];
    $golosel1 = resultado($id_jogo, $cod_sel1);
    $golosel2 = resultado($id_jogo, $cod_sel2);
    $estadio = get_estadio_jogo($id_jogo);
    $estadio = $estadio['nome'];
    $info = get_fase_data_jogo($id_jogo);
    $data = $info['data_jogo'];
    $fase = $info['fase'];
    $golos = get_golos($_GET['id_jogo']);
    $mensagem = "<h1 style='text-align:center;'>Final da Partida!!!</h1><p> Realizou-se hoje ( $data ), no estádio $estadio, o jogo da <b>fase: $fase </b> entre <b>$sel1</b> e $sel2</b>.</p>";
    if ($golosel1 > $golosel2) {
        $vencedor = $sel1;
        $mensagem1 = "O(A)<b> $vencedor venceu por $golosel1 - $golosel2.</b>"
                . "<p>O(A) <b>$sel1</b> utilizou os seguintes jogadores:";
    } else if ($golosel1 < $golosel2) {
        $vencedor = $sel2;
        $mensagem1 = "O(A)<b> $vencedor venceu por $golosel1 - $golosel2.</b>"
                . "<p>O(A) <b>$sel1</b> utilizou os seguintes jogadores:";
    } else if ($golosel1 == $golosel2) {
        $vencedor = 'empate';
        $mensagem1 = "O resultado entre as duas equipas foi um <b>empate a $golosel1 golo(s)</b>"
                . "<p>O(A) <b>$sel1</b> utilizou os seguintes jogadores:";
    }
    $jog1 = get_jogadores_uti_by_cod_sel($cod_sel1, $id_jogo);
    $jog2 = get_jogadores_uti_by_cod_sel($cod_sel2, $id_jogo);
    $mensagem2 = "";
    for ($i = 0; $i < count($jog1); $i++) {
        $jogador = $jog1[$i]['nome'];
        $mensagem2 = "$mensagem2 $jogador; ";
    }
    $mensagem3 = "<p>E pelo seu lado o(a) <b>$sel2</b> utilizou:";
    $mensagem4 = "";
    for ($i = 0; $i < count($jog2); $i++) {
        $jogador = $jog2[$i]['nome'];
        $mensagem4 = "$mensagem4 $jogador; ";
    }
    for ($i = 0; $i < count($golos); $i++) {
        if ($golos[$i]['pais'] == $sel1 || ($golos[$i]['pais'] == $sel2 && $golos[$i]['autogolo'] == 1)) {
            $golosMarc1[] = $golos[$i];
        } else {
            $golosMarc2[] = $golos[$i];
        }
    }
    $mensagem5 = "";
    if (isset($golosMarc1) || isset($golosMarc2)) {
        $mensagem5 = "<p><b>Os golos do jogo foram apontados por:</b></p>";
    }
    $mensagem6 = "";
    $mensagem7 = "";
    if (isset($golosMarc1)) {
        for ($i = 0; $i < count($golosMarc1); $i++) {
            $nome = $golosMarc1[$i]['nome'];
            $minuto = $golosMarc1[$i]['minuto'];

            if ($golosMarc1[$i]['autogolo'] == 0) {
                $mensagem6 = "$mensagem6 $nome - $minuto minutos; ";
            } else {
                $mensagem6 = "$mensagem6 $nome - $minuto minutos(autogolo); ";
            }
        }
        $mensagem7 = " <b>do lado do(a) $sel1. </b>";
    }
    $mensagem8 = "";
    $mensagem9 = "";
    if (isset($golosMarc2)) {
        $mensagem8 = "<b>Por parte do(a) $sel2 os golos foram apontados por:</b>";
        for ($i = 0; $i < count($golosMarc2); $i++) {
            $nome = $golosMarc2[$i]['nome'];
            $minuto = $golosMarc2[$i]['minuto'];
            if ($golosMarc2[$i]['autogolo'] == 0) {
                $mensagem9 = "$mensagem9 $nome - $minuto minutos; ";
            } else {
                $mensagem9 = "$mensagem9 $nome - $minuto minutos(autogolo); ";
            }
        }
    }
    $arbitrosDestacados = get_arbitros_destacados($id_jogo);
    $mensagem10 = "";
    $mensagem11 = "";
    if (count($arbitrosDestacados) > 0) {
        $mensagem10 = "<p>A Equipa de arbitragem nomeada para a partida foi a seguinte:</p>";
        $mensagem11 = "";
        for ($a = 0; $a < count($arbitrosDestacados); $a++) {
            $nome = $arbitrosDestacados[$a]['nome'];
            $mensagem11 = "$mensagem11 $nome; ";
        }
    }
    $mensagem12 = "<p>Mais uma vez assitiu-se a uma enorme partida de futebol! </p> <img style='width:70px;height:70px;margin-left:45%' src='http://upload.wikimedia.org/wikipedia/en/f/f7/FIFA_World_Cup_2018_Logo.png' alt='0'/>";
    $assunto = utf8_decode("$sel1 vs $sel2");
    $mensagemFinal = utf8_decode("$mensagem$mensagem1$mensagem2$mensagem3$mensagem4$mensagem5
            $mensagem6$mensagem7$mensagem8$mensagem9$mensagem10$mensagem11$mensagem12");
    $subscritores = getSubscritos('porJogo');
    $emails = "";
    for ($i = 0; $i < count($subscritores); $i++) {
        $email = $subscritores[$i]['email'];
        if ($i == count($subscritores) - 1) {
            $emails = "$emails$email";
        } else {
            $emails = "$emails$email ; ";
        }
    }
    enviarEmail($assunto, $mensagemFinal, $emails);
}

function subscrever($email, $subscricao) {
    $ligacao = ligar_base_dados();
    $count = "select count(*) from subscricoes where email='$email'";
    $existeOuNao = mysql_query($count, $ligacao);
    if ($existeOuNao) {
        $existeOuNao = mysql_fetch_array($existeOuNao);
    }
    if ($subscricao == 'ambos') {
        if ($existeOuNao[0] == 0) {
            $query = "Insert into subscricoes (email,diary,porJogo) values ('$email',1,1)";
        } else {
            $query = "UPDATE `fifawc2018`.`subscricoes` SET `diary`='1', `porJogo`='1' WHERE `email`='$email'";
        }
    } else if ($subscricao == 'diario') {
        if ($existeOuNao[0] == 0) {
            $query = "Insert into subscricoes (email,diary,porJogo) values ('$email',1,0)";
        } else {
            $query = "UPDATE `fifawc2018`.`subscricoes` SET `diary`='1', `porJogo`='0' WHERE `email`='$email'";
        }
    } else if ($subscricao == 'porJogo') {
        if ($existeOuNao[0] == 0) {
            $query = "Insert into subscricoes (email,diary,porJogo) values ('$email',0,1)";
        } else {
            $query = "UPDATE `fifawc2018`.`subscricoes` SET `diary`='0', `porJogo`='1' WHERE `email`='$email'";
        }
    } if ($subscricao == 'remover') {
        if ($existeOuNao[0] == 0) {
            return;
        } else {
            $query = "DELETE from subscricoes WHERE `email`='$email'";
        }
    }
    $resultado = mysql_query($query, $ligacao) or die('Error :' . \mysql_error($ligacao));
    $valor_retorno = false;
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $valor_retorno = true;
    }
    mysql_close($ligacao);
    return $valor_retorno;
}

function getSubscritos($tipo) {
    $ligacao = ligar_base_dados();
    if ($tipo == 'ambos') {
        $query = "Select email from subscricoes where porJogo=1 and diary=1";
    } else if ($tipo == 'diario') {
        $query = "Select email from subscricoes where diary=1";
    } else if ($tipo == 'porJogo') {
        $query = "Select email from subscricoes where porJogo=1";
    }
    $resultado = mysql_query($query, $ligacao);
    $subscritores = array();
    if ($resultado == false) {
        echo "<script language=javascript>alert( 'Ainda não existem subscrições!' );</script>";
    } else {
        while ($subscritor = mysql_fetch_assoc($resultado)) {
            $subscritores[] = $subscritor;
        }
    }
    mysql_close($ligacao);
    return $subscritores;
}

function listar_noticias() {
    $ligacao = ligar_base_dados();
    $date = date("Y-m-d");
    $date1 = date_create_from_format('Y-m-d', $date);
    $date2 = date_time_set($date1, 00, 00, 00);
    $date3 = date_format($date2, 'Y-m-d H:i:s');
    $date4 = date_create_from_format('Y-m-d', $date);
    $date5 = date_time_set($date4, 23, 59, 59);
    $date6 = date_format($date5, 'Y-m-d H:i:s');
    $query = "select j.terminado, j.data_jogo, s.Grupos_id_grupo, g.descricao, f.fase,  f.id_fase, e.n_golos, s.cod_sel, j.Estadios_id_estadio, s.pais, j.id_jogo
from jogos j, selecoesdestacadas e, fases f, selecoes s, grupos g
where  e.Jogos_id_jogo=j.id_jogo and s.Grupos_id_grupo=g.id_grupo and s.cod_sel=e.Selecoes_cod_sel
and f.id_fase=j.Fases_id_fase and j.data_jogo >= '$date3' and j.data_jogo <= '$date6' order by j.data_jogo asc, j.id_jogo asc, e.Selecoes_cod_sel asc";
    $resultado = mysql_query($query, $ligacao);
    $noticias = array();
    $jogos = array();
    if ($resultado == false) {
        die('Error :' . \mysql_error($ligacao));
    } else {
        $i = 0;
        $contador = 1;
        while ($jogo = mysql_fetch_array($resultado)) {
            $jogos[] = $jogo;
            if ($contador == 2) {
                if ($jogo['terminado'] == 1) {
                    $sel1 = $jogos[$i]['pais'];
                    $cod_sel1 = $jogos[$i]['cod_sel'];
                    $sel2 = $jogos[$i + 1]['pais'];
                    $cod_sel2 = $jogos[$i + 1]['cod_sel'];
                    $golos = get_golos($jogos[$i]['id_jogo']);
                    $sel1_golos = 0;
                    $sel2_golos = 0;
                    for ($z = 0; $z < count($golos); $z++) {
                        if (($golos[$z]['pais'] == $sel1) || ($golos[$z]['pais'] == $sel2 && $golos[$z]['autogolo'] == 1)) {
                            $sel1_golos++;
                        } else {
                            $sel2_golos++;
                        }
                    }
                    $descricao = "";
                    if (count($golos) == 0) {
                        $descricao = "As equipas empataram, sem golos, num jogo sem história.";
                    } else {
                        $descricao = "<p><b>Golos Marcados: </b></p>";
                    }
                    for ($a = 0; $a < count($golos); $a++) {
                        $descricao = $descricao . " -> " . $golos[$a]['nome'] . " - " . $golos[$a]['pais'] . " - " . $golos[$a]['minuto'] . " minutos<br>";
                    }
                    $arbitrosDestacados = get_arbitros_destacados($jogos[$i]['id_jogo']);
                    if (count($arbitrosDestacados) > 0) {
                        $descricao = "$descricao <p><b>A Equipa de arbitragem nomeada para a partida foi a seguinte:</b></p>";
                        for ($a = 0; $a < count($arbitrosDestacados); $a++) {
                            $nome = $arbitrosDestacados[$a]['nome'];
                            $descricao = "$descricao $nome; ";
                        }
                        
                    }
//                    $descricao = "$descricao <p>Mais uma vez assitiu-se a uma enorme partida de futebol! </p>";
                    $jog1 = get_jogadores_uti_by_cod_sel($cod_sel1, $jogos[$i]['id_jogo']);
                    $jog2 = get_jogadores_uti_by_cod_sel($cod_sel2, $jogos[$i]['id_jogo']);
                    if (count($jog1) > 0) {
                        $descricao = "$descricao <p><b>Jogadores Utilizados:</b></p> <b> -> $sel1:</b>";
                        for ($x = 0; $x < count($jog1); $x++) {
                            $jogador = $jog1[$x]['nome'];
                            $descricao = "$descricao $jogador; ";
                        }
                    }if (count($jog2) > 0) {
                        $descricao = "$descricao<p></p> <b> -> $sel2:</b>";
                        for ($x = 0; $x < count($jog2); $x++) {
                            $jogador = $jog2[$x]['nome'];
                            $descricao = "$descricao $jogador; ";
                        }
                    }
                    
                    $data = $jogos[$i]['data_jogo'];
                    $noticia = array('titulo' => "$sel1 $sel1_golos - $sel2_golos $sel2",
                        'data' => $data,
                        'descricao' => $descricao);

                    $contador = 0;
                }
                if ($jogo['terminado'] == 0) {
                    $sel1 = $jogos[$i]['pais'];
                    $sel2 = $jogos[$i + 1]['pais'];
                    $data = $jogos[$i]['data_jogo'];
                    $noticia = array('titulo' => "$sel1 - $sel2",
                        'data' => $data,
                        'descricao' => 'Por disputar. ');
                    $contador = 0;
                }
                $i = $i + 2;

                array_push($noticias, $noticia);
            }
            $contador++;
        }
    }
    return $noticias;
}
