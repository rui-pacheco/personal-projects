<?php
include ("top.php");
require_once 'funcoes.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

if (isset($_GET["selecao"])) {
    if (nGrupos($_GET["id_grupo"]) < 4) {
        adiciona_selecao_grupo($_GET["selecao"], $_GET["id_grupo"]);
        echo "<script language=javascript>alert( 'Selecao adicionada com sucesso!' );</script>";
    } else {
        echo "<script language=javascript>alert( 'Já registou 4 seleções!' );</script>";
    }
}
if (isset($_GET["rem_selecao"])) {
    if (remove_sel_grupo($_GET["rem_selecao"])) {
        echo "<script language=javascript>alert( 'Selecao removida com sucesso!' );</script>";
    }
}
?>
<div  class="registo">
    <h1>Editar Grupo</h1>
    <form method="post">
        <div>
            <h2><?= $_GET["descricao_grupo"] ?></h2> 
            <h3>Adicionar Seleções</h3>
            <?php
            $selecoes_sem_grupo = get_selecoes_by_grupo();
            if (empty($selecoes_sem_grupo)) {
                echo "<h4>Não existem seleçoes disponiveis para adicionar a este grupo</h4>";
            } else {
                ?>
                <table>
                    <tr>
                        <th>COD</th>
                        <th>Seleção</th>
                    </tr>
                    <?php
                    for ($i = 0; $i < count($selecoes_sem_grupo); $i++) {
                        ?>
                        <tr>
                            <td><?= $selecoes_sem_grupo[$i]["cod_sel"] ?></td>
                            <td><?= $selecoes_sem_grupo[$i]["pais"] ?></td>
                            <td> <a href="editarGrupos.php?selecao=<?= $selecoes_sem_grupo[$i]['cod_sel'] ?>
                                    &id_grupo=<?= $_GET['id_grupo'] ?>&descricao_grupo=
                                    <?= $_GET['descricao_grupo'] ?>"><input type="button" name="adicionar" value="adicionar"></a></td>
                        </tr>
                        <?php
                    }
                }
                ?>
   
            </table>
            <h3>Constituição do Grupo</h3>
            <?php
            $selecoes_grupo = get_selecoes_by_grupo($_GET["id_grupo"]);
            if (empty($selecoes_grupo)) {
                echo "<h4>Grupo Vazio</h4>";
            } else {
                ?>
                <table>
                    <tr>
                        <th>COD</th>
                        <th>Seleção</th>
                    </tr>
                    <?php
                    for ($i = 0; $i < count($selecoes_grupo); $i++) {
                        ?>
                        <tr>
                            <td><?= $selecoes_grupo[$i]["cod_sel"] ?></td>
                            <td><?= $selecoes_grupo[$i]["pais"] ?></td>
                            <td><a href="editarGrupos.php?rem_selecao=<?= $selecoes_grupo[$i]['cod_sel'] ?>
                                   &id_grupo=<?= $_GET['id_grupo'] ?>&descricao_grupo=
                                   <?= $_GET['descricao_grupo'] ?>"><input type="button" name="remover" value="remover"></a></td>
                        </tr>
                    <?php
                    }
                }
                ?>
                
            </table>

        </div>
    </form>
</div>
<?php } else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
