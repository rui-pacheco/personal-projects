<?php
include("top.php");
if (isset($_GET["edita_staff"])) {
    $staff = get_staff($_GET["edita_staff"]);
}
    if (isset($_SESSION['perfil']) && isset($_GET["edita_staff"]) && $_SESSION['perfil'] == 3 && $_SESSION['cod_sel'] == $staff["Selecoes_cod_sel"]) {

        if (isset($_GET["edita_staff"], $_GET["nome"])) {

            if (isset($_POST["g_sanguineo"])) {
                $id_funcao = get_id_funcao($_POST["funcao"]);
                editar_staff($staff["id_staff"], $_POST["data_nasc"], $_POST["sexo"], $_POST["g_sanguineo"], $id_funcao);
                $id = $staff["Selecoes_cod_sel"];
                $pais = $staff["pais"];
                redirect("editarSelecao.php?cod_sel=$id&pais=$pais");
            }
        }
        ?>
        <div class="registo">
            <h1> <?= $staff["nome"] ?> </h1>
            <form method="post">
                <p>Data de Nascimento: <input type="date" name="data_nasc" placeholder="aaaa-mm-dd" required value=<?= $staff["data_nasc"] ?>></p>
                <p>Sexo: 
                    <select name="sexo">
                        <option value="<?= $staff["sexo"] ?>"><?= $staff["sexo"] ?></option>
                        <option value="M">M</option> 
                        <option value="F">F</option> 
                    </select>
                </p>
                <p>Grupo Sanguíneo:
                    <select name="g_sanguineo">
                        <option value="<?= $staff["g_sanguineo"] ?>"><?= $staff["g_sanguineo"] ?></option>
                        <option value="A+">A+</option> 
                        <option value="A-">A-</option> 
                        <option value="AB+">AB+</option> 
                        <option value="AB-">AB-</option> 
                        <option value="B+">B+</option> 
                        <option value="B-">B-</option> 
                        <option value="O+">O+</option> 
                        <option value="O-">O-</option> 
                    </select></p>
                <p>Função:
                    <select name="funcao">
                        <?php
                        $funcoes = get_funcoes();
                        for ($i = 0; $i < count($funcoes); $i++) {
                            ?>
                            <option value="<?= $funcoes[$i] ?>"> <?= $funcoes[$i] ?></option> 
                        <?php } ?>
                        <option value="<?= $staff["descricao"] ?>"><?= $staff["descricao"] ?></option>
                    </select><br><br>
                    <input type="submit" value="Editar" >
            </form>
        </div>
        <?php
    } else {
        echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
    }
    