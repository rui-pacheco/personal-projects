<?php
include 'top.php';
if (isset($_POST['subscricao'])) {
    if (subscrever($_POST['mailSubs'], $_POST['subscricao'])) {
        echo "<script language=javascript>alert( 'Submetido com sucesso!' );</script>";
    }
}
?>
<div class="registo" style="margin-left: 35%">
    <form method="post">
        <h1>Subscrever</h1>
        <p>E-mail: <input type="email" required value="" name="mailSubs"></p>
        <p>Tipo: <select name="subscricao">
                <option value="diario">Diário</option>
                <option value="porJogo" selected="selected">Por Jogo</option>
                <option value="ambos">Ambos</option>
                <option value="remover">Remover Subscrição</option>
            </select></p>
        <input type="submit" value="Submeter">
    </form>
</div>
