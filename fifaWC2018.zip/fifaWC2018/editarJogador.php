<?php
include ("top.php");
if (isset($_GET["edita_jogador"])) {
    $jogador = get_jogador($_GET["edita_jogador"]);
}
if (isset($_SESSION['perfil']) && isset($_GET["edita_jogador"]) && $_SESSION['perfil'] == 3 && $_SESSION['cod_sel'] == $jogador["Selecoes_cod_sel"]) {

    if (isset($_GET["edita_jogador"], $_GET["nome"])) {

        if (isset($_POST["n_intern"])) {
            editar_jogador($jogador["id_jogador"], $_POST["posicao"], $_POST["data_nasc"], $_POST["g_sanguineo"], $_POST["peso"], $_POST["altura"], $_POST["n_camisola"], $_POST["n_intern"]);
            $id = $jogador["Selecoes_cod_sel"];
            $pais = $jogador["pais"];
            redirect("editarSelecao.php?cod_sel=$id&pais=$pais");
        }
    }
    ?>
    <div class="registo">
        <h1> <?= $jogador["nome"] ?> </h1>
        <form method="post">
            <p>Posição:
                <select name="posicao">
                    <option value="<?= $jogador["posicao"] ?>"><?= $jogador["posicao"] ?></option>
                    <option value="Guarda-redes">Guarda-redes</option> 
                    <option value="Defesa">Defesa</option> 
                    <option value="Médio">Médio</option> 
                    <option value="Avançado">Avançado</option> 
                </select></p>
            <p>Data de Nascimento: <input type="date" placeholder="aaaa-mm-dd" required name="data_nasc" value=<?= $jogador["data_nasc"] ?>></p>
            <p>Grupo Sanguíneo:
                <select name="g_sanguineo">
                    <option value="<?= $jogador["g_sanguineo"] ?>"><?= $jogador["g_sanguineo"] ?></option>
                    <option value="A+">A+</option> 
                    <option value="A-">A-</option> 
                    <option value="AB+">AB+</option> 
                    <option value="AB-">AB-</option> 
                    <option value="B+">B+</option> 
                    <option value="B-">B-</option> 
                    <option value="O+">O+</option> 
                    <option value="O-">O-</option> 
                </select></p>
            <p>Peso: <input type="number" name="peso" min="0" placeholder="Kilos" max="150" title="Apenas numeros" pattern="[0-9]+" required value=<?= $jogador["peso"] ?>></p>
            <p>Altura:<input type="number" name="altura" min="0" placeholder="Centimetros" max="150" title="Apenas numeros" pattern="[0-9]+" required value=<?= $jogador["altura"] ?>></p>
            <p>Nº Camisola:<input type="number" min="0"  max="23" title="Apenas numeros" pattern="[0-9]+" required name="n_camisola" value=<?= $jogador["n_camisola"] ?>></p>
            <p>Nº Internacionalizações:<input type="number" min="0" title="Apenas numeros" pattern="[0-9]+" required name="n_intern" value=<?= $jogador["n_intern"] ?>></p>
            <input type="submit" value="Editar" >
        </form>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
