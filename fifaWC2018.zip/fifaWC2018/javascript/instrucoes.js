
var map;
function initialize1() {
    var mapOptions = {
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById('map-canvas'),
            mapOptions);
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
            var infowindow = new google.maps.InfoWindow({
                map: map,
                position: pos,
                content: 'Você está aqui!'
            });
            map.setCenter(pos);
        });
    }
}
//google.maps.event.addDomListener(window, 'load', initialize1);

function direcao() {
    var directionsService = new google.maps.DirectionsService(),
            directionsDisplay = new google.maps.DirectionsRenderer(),
            createMap = function (start) {
                var travel = {
                    origin: (start.coords) ? new google.maps.LatLng(start.lat, start.lng) : start.address,
                    destination: document.getElementById('address').value,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING
                },
                mapOptions = {
                    zoom: 10,
                    center: new google.maps.LatLng(59.3325215, 18.0643818),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };

                map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
                directionsDisplay.setMap(map);
                directionsService.route(travel, function (result, status) {
                    if (status === google.maps.DirectionsStatus.OK) {
                        directionsDisplay.setDirections(result);
                    }
                });
            };
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            createMap({
                coords: true,
                lat: position.coords.latitude,
                lng: position.coords.longitude
            });
        }
        );
    }
}

google.maps.event.addDomListener(window, 'load', direcao);

window.onload = function () {
    var xmlhttp = new XMLHttpRequest();

    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            var xmlDoc = xmlhttp.responseXML;
            var txt = "";
            var icon = "";
            var data = "";
            var x = xmlDoc.getElementsByTagName("symbol");
            var y = xmlDoc.getElementsByTagName("temperature");
            var z = xmlDoc.getElementsByTagName("time");
            var temp = "";

            temp = y[0].getAttribute("day");
            txt = x[0].getAttribute("name");
            icon = x[0].getAttribute("var");
            data = z[0].getAttribute("day");
            
            document.getElementById("icone").src = "http://openweathermap.org/img/w/" + icon + ".png";
            document.getElementById("tempo").innerHTML = txt;
            document.getElementById("temperatura").innerHTML = " " + temp + " ºC";
            icon = x[1].getAttribute("var");
            document.getElementById("prev1").src = "http://openweathermap.org/img/w/" + icon + ".png";
            icon = x[2].getAttribute("var");
            document.getElementById("prev2").src = "http://openweathermap.org/img/w/" + icon + ".png";
            icon = x[3].getAttribute("var");
            document.getElementById("prev3").src = "http://openweathermap.org/img/w/" + icon + ".png";

            document.getElementById("data").innerHTML = "Condições atuais: "+data;
            data = z[1].getAttribute("day");
            document.getElementById("data1").innerHTML = data;
            data = z[2].getAttribute("day");
            document.getElementById("data2").innerHTML = data;
            data = z[3].getAttribute("day");
            document.getElementById("data3").innerHTML = data;


        }
    }
    xmlhttp.open("GET", "http://api.openweathermap.org/data/2.5/forecast/daily?q=" + document.getElementById("cidade").innerHTML + "&mode=xml&units=metric&cnt=4&lang=pt", true);
    xmlhttp.send();
}

function calcRoute() {

    var directionsService = new google.maps.DirectionsService(),
            directionsDisplay = new google.maps.DirectionsRenderer(),
            createMap = function () {
                var travel = {
                    origin: document.getElementById('start').value,
                    destination: document.getElementById('address').value,
                    travelMode: google.maps.DirectionsTravelMode.DRIVING
                },
                mapOptions = {
                    zoom: 10,
                    center: new google.maps.LatLng(59.3325215, 18.0643818),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };

                map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
                directionsDisplay.setMap(map);
                directionsService.route(travel, function (result, status) {
                    if (status === google.maps.DirectionsStatus.OK) {
                        directionsDisplay.setDirections(result);
                    }
                });
            };
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            createMap({
                coords: true,
                lat: position.coords.latitude,
                lng: position.coords.longitude
            });
        }
        );
    }
}


