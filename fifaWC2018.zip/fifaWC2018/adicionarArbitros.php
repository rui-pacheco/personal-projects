<?php
include 'top.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
    if (isset($_GET['arbitro'])) {
        adiciona_arbitros($_GET['id_jogo'], $_GET['tipo'], $_GET['arbitro']);
    }
    ?>
    <div class="fundo">
        <h1>Equipa de Arbitragem</h1>
        <form method="get" style="margin-left: 30%;">
            <p> Árbitro: <select name="arbitro">
                    <?php
                    $arbitros = get_todos_arbitros();
                    for ($i = 0; $i < count($arbitros); $i++) {
                        $id = $arbitros[$i]['id_arbitro'];
                        ?>
                        <option value="<?= $arbitros[$i]['id_arbitro'] ?>"><?= $arbitros[$i]['nome'] ?> - <?= $arbitros[$i]['nacionalidade'] ?></option>
                    <?php }
                    ?>
                </select></p>
            <p> Função: <select name="tipo">
                    <option value="1" selected>Principal</option>
                    <option value="2">Assistente</option>
                    <option value="3">Quarto Árbitro</option>
                </select>
                <input type="hidden" name="id_jogo" value="<?= $_GET['id_jogo'] ?>">
                <input type="submit" value="adicionar"></p>
        </form><br/>
        <table class="tablePequena">
            <tr><th colspan="3">Árbitros Destacados</th></tr>
            <tr><th>Nome</th>
                <th>Nacionalidade</th>
                <th>Tipo</th></tr>
            <?php
            $arbitrosDestacados = get_arbitros_destacados($_GET['id_jogo']);
            for ($a = 0; $a < count($arbitrosDestacados); $a++) {
                ?><tr>
                    <td><?= $arbitrosDestacados[$a]['nome'] ?></td>
                    <td><?= $arbitrosDestacados[$a]['nacionalidade'] ?></td>
                    <td><?= $arbitrosDestacados[$a]['descricao'] ?></td></tr>
                <?php
            }
            ?>
        </table>
        <br/>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
