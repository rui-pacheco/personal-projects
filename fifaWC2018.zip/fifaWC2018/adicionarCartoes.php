<?php
include 'top.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
    if (isset($_POST["sel1"])) {
        if (nCartoesAmarelos($_GET["id_jogo"], $_POST["penalizado_sel1"]) == 0) {
            atribuir_cartoes($_POST["minuto_sel1"], $_POST["penalizado_sel1"], $_POST["tipo1"], $_GET["id_jogo"]);
            echo "<script language=javascript>alert( 'Cartão adicionado com sucesso' );</script>";
        } else if (nCartoesAmarelos($_GET["id_jogo"], $_POST["penalizado_sel1"]) == 1) {
            atribuir_cartoes($_POST["minuto_sel1"], $_POST["penalizado_sel1"], $_POST["tipo1"], $_GET["id_jogo"]);
            cartoesVermelhos($_POST["penalizado_sel1"], $_GET["id_jogo"]);
            echo "<script language=javascript>alert( 'Cartão adicionado com sucesso' );</script>";
        } else {
            echo "<script language=javascript>alert( 'O jogador já foi expulso' );</script>";
        }
    }
    if (isset($_POST["sel2"])) {
        if (nCartoesAmarelos($_GET["id_jogo"], $_POST["penalizado_sel2"]) == 0) {
            atribuir_cartoes($_POST["minuto_sel2"], $_POST["penalizado_sel2"], $_POST["tipo2"], $_GET["id_jogo"]);
            echo "<script language=javascript>alert( 'Cartão adicionado com sucesso' );</script>";
        } else if (nCartoesAmarelos($_GET["id_jogo"], $_POST["penalizado_sel2"]) == 1) {
            atribuir_cartoes($_POST["minuto_sel2"], $_POST["penalizado_sel2"], $_POST["tipo2"], $_GET["id_jogo"]);
            cartoesVermelhos($_POST["penalizado_sel2"], $_GET["id_jogo"]);
            echo "<script language=javascript>alert( 'Cartão adicionado com sucesso' );</script>";
        } else {
            echo "<script language=javascript>alert( 'O jogador já foi expulso' );</script>";
        }
    }
    ?>
    <div class="fundo">
        <div style="display: inline-block;margin-left:20%">
            <form method="post">

                <h1><?= $_GET['selecao1'] ?></h1>
                <br>
                <h2>Cartões</h2>
                <p>Vermelho <input type="radio" name="tipo1" value="1" >
                    Amarelo <input type="radio" name="tipo1" value="0" selected >
                    <br>
                    <br>
                    Minuto: <input type="number" name="minuto_sel1" max="120" min="0" title="Apenas numeros" pattern="[0-9]+" required value="">
                    <br>
                    <br>
                    Jogador penalizado:
                    <select name="penalizado_sel1">
                        <?php
                        $jogadores_uti_sel1 = get_jogadores_uti_by_cod_sel($_GET['cod_sel1'], $_GET['id_jogo']);
                        for ($i = 0; $i < count($jogadores_uti_sel1); $i++) {
                            ?>
                            <option value="<?= $jogadores_uti_sel1[$i]['id_jogador'] ?>"><?= $jogadores_uti_sel1[$i]['nome'] ?></option>
                        <?php }
                        ?>
                    </select>
                </p>
                <input type="hidden" name="id_jogo" value="<?= $_POST['id_jogo'] ?>">
                <input type="hidden" name="cod_sel1" value="<?= $_POST['cod_sel1'] ?>">
                <input type="hidden" name="cod_sel2" value="<?= $_POST['cod_sel2'] ?>">
                <input type="hidden" name="sel1" value="1">


                <input type="submit" value="adicionar cartão">

            </form><br></div>
        <div style="display:inline-block;margin-left: 10%;">

            <form method="post">
                <h1><?= $_GET['selecao2'] ?></h1>
                <br>
                <h2>Cartões</h2>
                <p>Vermelho <input type="radio" name="tipo2" value="1">
                    Amarelo <input type="radio" name="tipo2" value="0" selected>
                    <br>
                    <br>
                    Minuto: <input type="number" name="minuto_sel2" min="0" max="120" value=""title="Apenas numeros" pattern="[0-9]+" required>
                    <br>
                    <br>
                    Jogador penalizado:
                    <select name="penalizado_sel2">
                        <?php
                        $jogadores_uti_sel2 = get_jogadores_uti_by_cod_sel($_GET['cod_sel2'], $_GET['id_jogo']);
                        for ($i = 0; $i < count($jogadores_uti_sel2); $i++) {
                            ?>
                            <option value="<?= $jogadores_uti_sel2[$i]['id_jogador'] ?>"><?= $jogadores_uti_sel2[$i]['nome'] ?></option>
                        <?php }
                        ?>
                    </select>
                </p>
                <input type="hidden" name="id_jogo" value="<?= $_POST['id_jogo'] ?>">
                <input type="hidden" name="cod_sel2" value="<?= $_POST['cod_sel2'] ?>">
                <input type="hidden" name="cod_sel1" value="<?= $_POST['cod_sel1'] ?>">
                <input type="hidden" name="sel2" value="2">
                <input type="submit" value="adicionar cartão">
            </form><br>
        </div>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}