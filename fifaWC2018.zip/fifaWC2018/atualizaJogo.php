<?php
include 'top.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {


if (isset($_POST['ad_uti'])) {

    if (isset($_POST['jogadores_uti1'])){ 
        $jogadores1 = get_jogadores_uti_by_cod_sel($_GET["cod_sel1"], $_GET["id_jogo"]);


        if ((count($jogadores1) + count($_POST["jogadores_uti1"]) <= 14)) {
            $jogadores_uti1 = $_POST['jogadores_uti1'];
            for ($i = 0; $i < count($jogadores_uti1); $i++) {
                if (in_array($jogadores_uti1[$i], $jogadores1)) {
                    echo "<script language=javascript>alert( 'este jogador já foi adicionado!' );</script>";
                } else {
                    jogador_utilizado($jogadores_uti1[$i], $_POST['id_jogo']);
                }
            }
        } else {
            echo "<script language=javascript>alert( 'cada seleção só pode ter entre 11 e 14 jogadores utilizados por jogo!' );</script>";
        }
    }
    if (isset($_POST['jogadores_uti2'])) {
        $jogadores2 = get_jogadores_uti_by_cod_sel($_GET["cod_sel2"], $_GET["id_jogo"]);
        if ((count($jogadores2) + count($_POST["jogadores_uti2"]) <= 14)) {
            $jogadores_uti2 = $_POST['jogadores_uti2'];
            for ($i = 0; $i < count($jogadores_uti2); $i++) {
                if (in_array($jogadores_uti2[$i], $jogadores2)) {
                    echo "<script language=javascript>alert( 'este jogador já foi adicionado!' );</script>";
                } else {
                    jogador_utilizado($jogadores_uti2[$i], $_POST['id_jogo']);
                }
            }
        } else {
            echo "<script language=javascript>alert( 'cada seleção só pode ter entre 11 e 14 jogadores utilizados por jogo!' );</script>";
        }
    }
}
?>

<div class="fundo">
    <h1>Atualizar Jogos</h1>
    <form method="post">
            <div style="display: inline-block;margin-left:20%">
                <h2>Jogadores utilizados <br><?= $_GET['selecao1'] ?></h2>
                <select multiple="14" name="jogadores_uti1[]" size="11">
                    <?php
                    $cod_sel1 = $_GET['cod_sel1'];
                    $jogadores_sel1 = get_jogadores_by_sel($cod_sel1);
                    for ($i = 0; $i < count($jogadores_sel1); $i++) {
                        ?>
                        <option value="<?= $jogadores_sel1[$i]['id_jogador'] ?>"><?= $jogadores_sel1[$i]['nome'] ?></option>
                    <?php }
                    ?>

                </select>
            </div>
            <div style="display:inline-block;margin-left: 10%;">
                <h2>Jogadores utilizados <br><?= $_GET['selecao2'] ?></h2>
                <select multiple="14" name="jogadores_uti2[]" size="11">
                    <?php
                    $cod_sel2 = $_GET['cod_sel2'];
                    $jogadores_sel2 = get_jogadores_by_sel($cod_sel2);
                    for ($i = 0; $i < count($jogadores_sel2); $i++) {
                        ?>
                        <option value="<?= $jogadores_sel2[$i]['id_jogador'] ?>"><?= $jogadores_sel2[$i]['nome'] ?></option>
                        <?php
                    }
                    ?>
                </select>
            </div>
            <br>
            <br>
            <input type="hidden" name="id_jogo" value="<?= $_GET['id_jogo'] ?>">
            <input type="hidden" name="cod_sel1" value="<?= $_GET['cod_sel1'] ?>">
            <input type="hidden" name="cod_sel2" value="<?= $_GET['cod_sel2'] ?>">
            <input type="submit" name="ad_uti" class="botao" value="submeter">
    </form>
    <div style="display: inline-block;margin-left:20%">
        <table class="tablePequena">
            <tr>
                <th colspan="2">Jogadores já adicionados <?= $_GET["selecao1"] ?></th>
            </tr>
            <tr>
                <th>Id</th>
                <th>Jogador</th>
            </tr>

            <?php
            $jog1 = get_jogadores_uti_by_cod_sel($_GET["cod_sel1"], $_GET["id_jogo"]);
            for ($i = 0; $i < count($jog1); $i++) {
                ?>
                <tr>
                    <td><?= $jog1[$i]["id_jogador"] ?></td>
                    <td><?= $jog1[$i]["nome"] ?></td>
                </tr>
            <?php }
            ?>

        </table>
        <br>
    </div>
    <div style="display:inline-block;margin-left: 10%;">
        <table class="tablePequena">
            <tr>
                <th colspan="2">Jogadores já adicionados <?= $_GET["selecao2"] ?></th>
            </tr>
            <tr>
                <th>Id</th>
                <th>Jogador</th>
            </tr>

            <?php
            $jog2 = get_jogadores_uti_by_cod_sel($_GET["cod_sel2"], $_GET["id_jogo"]);
            for ($i = 0; $i < count($jog2); $i++) {
                ?>
                <tr>
                    <td><?= $jog2[$i]["id_jogador"] ?></td>
                    <td><?= $jog2[$i]["nome"] ?></td>
                </tr>
            <?php }
            ?>

        </table>
        <br>
    </div>
<?php } else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
