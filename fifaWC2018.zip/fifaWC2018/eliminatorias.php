<?php
include("top.php");
include 'isAlterado.php';
$grupos = get_descricao_grupos();
$num_grupos = count($grupos);

if (isset($_GET['oitavos'])) {
    $apuramento1 = $_GET['id_apuramento1'];
    $apuramento2 = $_GET['id_apuramento2'];
    $cod_sel1=$_GET['cod_sel1'];
    $cod_sel2=$_GET['cod_sel2'];
    if ($apuramento1 == 1) {
        if(get_oponente(2)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(2),2));
        }
    } else if ($apuramento1 == 3) {
        if(get_oponente(4)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(4),2));
        }
    } else if ($apuramento1 == 5) {
        if(get_oponente(6)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(6),2));
        }
    } else if ($apuramento1 == 7) {
        if(get_oponente(8)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(8),2));
        }
    } else if ($apuramento1 == 10) {
        if(get_oponente(9)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(9),2));
        }
    } else if ($apuramento1 == 12) {
        if(get_oponente(11)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(11),2));
        }
    } else if ($apuramento1 == 14) {
        if(get_oponente(13)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(13),2));
        }
    } else if ($apuramento1 == 16) {
        if(get_oponente(15)==null){
            cria_eliminatorias($cod_sel1, 2);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(15),2));
        }
    }
    
    if($apuramento2 == 2){
        if(get_oponente(1)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            echo get_oponente(1);
            echo $cod_sel2;
            update_jo($cod_sel2, get_id_jogo(get_oponente(1),2));
        }
    }else if($apuramento2 == 4){
        if(get_oponente(3)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(3),2));
        }
    }else if($apuramento2 == 6){
        if(get_oponente(5)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(5),2));
        }
    }else if($apuramento2 == 8){
        if(get_oponente(7)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(7),2));
        }
    }else if($apuramento2 == 9){
        if(get_oponente(10)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(10),2));
        }
    }else if($apuramento2 == 11){
        if(get_oponente(12)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(12),2));
        }
    }else if($apuramento2 == 13){
        if(get_oponente(14)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(14),2));
        }
    }else if($apuramento2 == 15){
        if(get_oponente(16)==null){
            cria_eliminatorias($cod_sel2, 2);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(16),2));
        }
    }
}
if(isset($_GET['quartos'])){
    $apuramento=$_GET['id_apuramento'];
    $cod_sel=$_GET['cod_sel'];
    if($apuramento==17){
        if(get_oponente(18)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(18),3));
        }
    }else if($apuramento==18){
        if(get_oponente(17)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(17),3));
        }
    }else if($apuramento==19){
        if(get_oponente(20)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(20),3));
        }
    }else if($apuramento==20){
        if(get_oponente(19)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(19),3));
        }
    }else if($apuramento==21){
        if(get_oponente(22)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(22),3));
        }
    }else if($apuramento==22){
        if(get_oponente(21)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(21),3));
        }
    }else if($apuramento==23){
        if(get_oponente(24)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(24),3));
        }
    }else if($apuramento==24){
        if(get_oponente(23)==null){
            cria_eliminatorias($cod_sel, 3);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(23),3));
        }
    }
}
if(isset($_GET['meias'])){
    $apuramento=$_GET['id_apuramento'];
    $cod_sel=$_GET['cod_sel'];
    if($apuramento==25){
        if(get_oponente(26)==null){
            cria_eliminatorias($cod_sel, 4);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(26),4));
        }
    }else if($apuramento==26){
        if(get_oponente(25)==null){
            cria_eliminatorias($cod_sel, 4);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(25),4));
        }
    }else if($apuramento==27){
        if(get_oponente(28)==null){
            cria_eliminatorias($cod_sel, 4);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(28),4));
        }
    }else if($apuramento==28){
        if(get_oponente(27)==null){
            cria_eliminatorias($cod_sel, 4);
        }else{
            update_jo($cod_sel, get_id_jogo(get_oponente(27),4));
        }
    }
}
if (isset($_GET['finais'])) {
    $apuramento1 = $_GET['id_apuramento1'];
    $apuramento2 = $_GET['id_apuramento2'];
    $cod_sel1=$_GET['cod_sel1'];
    $cod_sel2=$_GET['cod_sel2'];
    if ($apuramento1 == 31) {
        if(get_oponente(32)==null){
            cria_eliminatorias($cod_sel1, 6);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(32),6));
        }
    } else if ($apuramento1 == 32) {
        if(get_oponente(31)==null){
            cria_eliminatorias($cod_sel1, 6);
        }else{
            update_jo($cod_sel1, get_id_jogo(get_oponente(31),6));
        }
    }
    
    if($apuramento2 == 29){
        if(get_oponente(30)==null){
            cria_eliminatorias($cod_sel2, 5);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(30),5));
        }
    }else if($apuramento2 == 30){
        if(get_oponente(29)==null){
            cria_eliminatorias($cod_sel2, 5);
        }else{
            update_jo($cod_sel2, get_id_jogo(get_oponente(29),5));
        }
    }
}
?>
<div class="fundo">
    <h1>Eliminatórias</h1>
    <table id="experiencia">

        <tbody>
            <tr>
                <td>
                    <div class="esquema">
                        <div class="fases">1/8</div>
                        <div class="fases">1/4</div>
                        <div class="fases">1/2</div>
                        <div class="fases" style="width: 94px">Final</div>
                        <div class="fases">1/2</div>
                        <div class="fases">1/4</div>
                        <div class="fases">1/8</div>

                        <div class="jogo" style="top:223px;left:362px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(2),2)?>&cod_sel1=<?=get_oponente(1)?>&cod_sel2=<?=get_oponente(1)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(1), 2), get_oponente(1))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(2), 2), get_oponente(2))?>
                               &selecao1=<?=get_nome_oponente(1)?>&selecao2=<?=get_nome_oponente(2)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(1)==NULL){
                                            if($num_grupos >= 1) { ?>
                                            1º <?= $grupos[0]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_nome_oponente(1);
                                        } ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(1), 2), get_oponente(1))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(2)==NULL){
                                            if($num_grupos >= 2) { ?>
                                            2º <?= $grupos[1]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_nome_oponente(2);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(2), 2), get_oponente(2))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:314px;left:362px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(4),2)?>&cod_sel1=<?=get_oponente(3)?>&cod_sel2=<?=get_oponente(4)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(3), 2), get_oponente(3))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(4), 2), get_oponente(4))?>
                               &selecao1=<?=get_nome_oponente(3)?>&selecao2=<?=get_nome_oponente(4)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px"> 
                                        <?php if(get_oponente(3)==NULL){
                                            if($num_grupos >= 3) { ?>
                                            1º <?= $grupos[2]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(3);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(3), 2), get_oponente(3))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(4)==NULL){
                                            if($num_grupos >= 4) { ?>
                                            2º <?= $grupos[3]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(4);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(4), 2), get_oponente(4))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:223px;left:880px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(9),2)?>&cod_sel1=<?=get_oponente(10)?>&cod_sel2=<?=get_oponente(9)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(10), 2), get_oponente(10))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(9), 2), get_oponente(9))?>
                               &selecao1=<?=get_nome_oponente(10)?>&selecao2=<?=get_nome_oponente(9)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(10)==NULL){
                                            if($num_grupos >= 2) { ?>
                                            1º <?= $grupos[1]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(10);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(10), 2), get_oponente(10))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(9)==NULL){
                                            if($num_grupos >= 1) { ?>
                                            2º <?= $grupos[0]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(9);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(9), 2), get_oponente(9))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:314px;left:880px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(11),2)?>&cod_sel1=<?=get_oponente(12)?>&cod_sel2=<?=get_oponente(11)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(12), 2), get_oponente(12))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(11), 2), get_oponente(11))?>
                               &selecao1=<?=get_nome_oponente(12)?>&selecao2=<?=get_nome_oponente(11)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(12)==NULL){
                                            if($num_grupos >= 4) { ?>
                                            1º <?= $grupos[3]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(12);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(12), 2), get_oponente(12))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(11)==NULL){
                                            if($num_grupos >= 3) { ?>
                                            2º <?= $grupos[2]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(11);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(11), 2), get_oponente(11))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:410px;left:362px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(6),2)?>&cod_sel1=<?=get_oponente(5)?>&cod_sel2=<?=get_oponente(6)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(5), 2), get_oponente(5))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(6), 2), get_oponente(6))?>
                               &selecao1=<?=get_nome_oponente(5)?>&selecao2=<?=get_nome_oponente(6)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(5)==NULL){
                                            if($num_grupos >= 5) { ?>
                                            1º <?= $grupos[4]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(5);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(5), 2), get_oponente(5))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(6)==NULL){
                                            if($num_grupos >= 6) { ?>
                                            2º <?= $grupos[5]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(6);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(6), 2), get_oponente(6))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:501px;left:362px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(8),2)?>&cod_sel1=<?=get_oponente(7)?>&cod_sel2=<?=get_oponente(8)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(7), 2), get_oponente(7))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(8), 2), get_oponente(8))?>
                               &selecao1=<?=get_nome_oponente(7)?>&selecao2=<?=get_nome_oponente(8)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(7)==NULL){
                                            if($num_grupos >= 7) { ?>
                                            1º <?= $grupos[6]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(7);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(7), 2), get_oponente(7))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(8)==NULL){
                                            if($num_grupos >= 8) { ?>
                                            2º <?= $grupos[7]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(8);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(8), 2), get_oponente(8))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:410px;left:880px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(13),2)?>&cod_sel1=<?=get_oponente(14)?>&cod_sel2=<?=get_oponente(13)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(14), 2), get_oponente(14))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(13), 2), get_oponente(13))?>
                               &selecao1=<?=get_nome_oponente(14)?>&selecao2=<?=get_nome_oponente(13)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(14)==NULL){
                                            if($num_grupos >= 6) { ?>
                                            1º <?= $grupos[5]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(14);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(14), 2), get_oponente(14))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(13)==NULL){
                                            if($num_grupos >= 5) { ?>
                                            2º <?= $grupos[4]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(13);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(13), 2), get_oponente(13))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:501px;left:880px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(15),2)?>&cod_sel1=<?=get_oponente(16)?>&cod_sel2=<?=get_oponente(15)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(16), 2), get_oponente(16))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(15), 2), get_oponente(15))?>
                               &selecao1=<?=get_nome_oponente(16)?>&selecao2=<?=get_nome_oponente(15)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(16)==NULL){
                                            if($num_grupos >= 8) { ?>
                                            1º <?= $grupos[7]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(16);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(16), 2), get_oponente(16))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php if(get_oponente(15)==NULL){
                                            if($num_grupos >= 7) { ?>
                                            2º <?= $grupos[6]['descricao'] ?>
                                        <?php } 
                                        }else{
                                            echo get_oponente(15);
                                        } ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(15), 2), get_oponente(15))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:455px;left:446px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(20),3)?>&cod_sel1=<?=get_oponente(19)?>&cod_sel2=<?=get_oponente(20)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(19), 3), get_oponente(19))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(20), 3), get_oponente(20))?>
                               &selecao1=<?=get_nome_oponente(19)?>&selecao2=<?=get_nome_oponente(20)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(19)==null){
                                            
                                        }else{
                                            echo get_oponente(19);
                                        }
                                        ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(19), 3), get_oponente(19))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(20)==null){
                                            
                                        }else{
                                            echo get_oponente(20);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(20), 3), get_oponente(20))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:269px;left:446px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(18),3)?>&cod_sel1=<?=get_oponente(17)?>&cod_sel2=<?=get_oponente(18)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(17), 3), get_oponente(17))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(18), 3), get_oponente(18))?>
                               &selecao1=<?=get_nome_oponente(17)?>&selecao2=<?=get_nome_oponente(18)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(17)==null){
                                            
                                        }else{
                                            echo get_oponente(17);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(17), 3), get_oponente(17))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(18)==null){
                                            
                                        }else{
                                            echo get_oponente(18);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(18), 3), get_oponente(18))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:455px;left:796px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(24),3)?>&cod_sel1=<?=get_oponente(23)?>&cod_sel2=<?=get_oponente(24)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(23), 3), get_oponente(23))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(24), 3), get_oponente(24))?>
                               &selecao1=<?=get_nome_oponente(23)?>&selecao2=<?=get_nome_oponente(24)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(23)==null){
                                            
                                        }else{
                                            echo get_oponente(23);
                                        }
                                        ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(23), 3), get_oponente(23))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(24)==null){
                                            
                                        }else{
                                            echo get_oponente(24);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(24), 3), get_oponente(24))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:269px;left:796px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(22),3)?>&cod_sel1=<?=get_oponente(21)?>&cod_sel2=<?=get_oponente(22)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(21), 3), get_oponente(21))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(22), 3), get_oponente(22))?>
                               &selecao1=<?=get_nome_oponente(21)?>&selecao2=<?=get_nome_oponente(22)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(21)==null){
                                            
                                        }else{
                                            echo get_oponente(21);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(21), 3), get_oponente(21))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(22)==null){
                                            
                                        }else{
                                            echo get_oponente(22);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(22), 3), get_oponente(22))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a> </div>
                        <div class="jogo" style="top:362px;left:531px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(26),4)?>&cod_sel1=<?=get_oponente(25)?>&cod_sel2=<?=get_oponente(26)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(25), 4), get_oponente(25))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(26), 4), get_oponente(26))?>
                               &selecao1=<?=get_nome_oponente(25)?>&selecao2=<?=get_nome_oponente(26)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(25)==null){
                                            
                                        }else{
                                            echo get_oponente(25);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(25), 4), get_oponente(25))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(26)==null){
                                            
                                        }else{
                                            echo get_oponente(26);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(26), 4), get_oponente(26))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:362px;left:711px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(28),4)?>&cod_sel1=<?=get_oponente(27)?>&cod_sel2=<?=get_oponente(28)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(27), 4), get_oponente(27))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(28), 4), get_oponente(28))?>
                               &selecao1=<?=get_nome_oponente(27)?>&selecao2=<?=get_nome_oponente(28)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(27)==null){
                                            
                                        }else{
                                            echo get_oponente(27);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(27), 4), get_oponente(27))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(28)==null){
                                            
                                        }else{
                                            echo get_oponente(28);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(28), 4), get_oponente(28))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a> </div>
                        <div class="jogo" style="top:485px;left:614px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(30),5)?>&cod_sel1=<?=get_oponente(29)?>&cod_sel2=<?=get_oponente(30)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(29), 5), get_oponente(29))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(30), 5), get_oponente(30))?>
                               &selecao1=<?=get_nome_oponente(29)?>&selecao2=<?=get_nome_oponente(30)?>">
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(29)==null){
                                            
                                        }else{
                                            echo get_oponente(29);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(29), 5), get_oponente(29))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome" style="margin-left: 4px">
                                        <?php
                                        if(get_oponente(30)==null){
                                            
                                        }else{
                                            echo get_oponente(30);
                                        }
                                        ?>
                                    </div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(30), 5), get_oponente(30))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                        <div class="jogo" style="top:330px;left:614px;">
                            <a href="verJogo.php?id_jogo=<?=get_id_jogo(get_oponente(32),6)?>&cod_sel1=<?=get_oponente(31)?>&cod_sel2=<?=get_oponente(32)?>
                               &golos1=<?=  resultado(get_id_jogo(get_oponente(31), 6), get_oponente(31))?>&golos2=<?=  resultado(get_id_jogo(get_oponente(32), 6), get_oponente(32))?>
                               &selecao1=<?=get_nome_oponente(31)?>&selecao2=<?=get_nome_oponente(32)?>">
                                <div class="estadio"> </div>
                                <div class="equipa">
                                    <div class="equipaNome">
                                        <?php
                                        if(get_oponente(31)==null){
                                            
                                        }else{
                                            echo get_oponente(31);
                                        }
                                        ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(31), 6), get_oponente(31))?></div>
                                </div>
                                <div class="equipa">
                                    <div class="equipaNome"><?php
                                        if(get_oponente(32)==null){
                                            
                                        }else{
                                            echo get_oponente(32);
                                        }
                                        ?></div>
                                    <div class="resultado"><?=  resultado(get_id_jogo(get_oponente(32), 6), get_oponente(32))?></div>
                                </div>
                                <!--                                <div class="data">
                                                                    <br>
                                                                    <b> (3-2)g.p.</b>
                                                                </div>-->
                            </a></div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table><br><br>
</div>

