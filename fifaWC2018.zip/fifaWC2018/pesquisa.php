<?php

include "top.php";
include 'isAlterado.php';
$procura = $_POST['procura'];

?>
<div class="registo">
<h1>Resultados da Pesquisa</h1>
<?php procura($procura); ?>
</div>

