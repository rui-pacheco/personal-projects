<?php
include("top.php");
if (isset($_SESSION['perfil']) && isset($_GET["registar"]) && $_SESSION['perfil'] == 3 && $_SESSION['cod_sel'] == $_GET["registar"]) {

if (isset($_GET["registar"])) {
    if (isset($_POST["nome"], $_POST["posicao"], $_POST["data_nasc"], $_POST["g_sanguineo"], $_POST["peso"], $_POST["altura"], $_POST["n_camisola"], $_POST["n_intern"])) {
        $cod_sel = $_GET["registar"];
        if (nJogadores($cod_sel) < 23) {
            while ($jogador = repetirJogador($cod_sel)) {
                if ($jogador['nome'] <> $_POST["nome"] && $jogador['n_camisola'] <> $_POST["n_camisola"]) {
                    regista_jogador($_POST["nome"], $_POST["posicao"], $_POST["data_nasc"], $_POST["g_sanguineo"], $_POST["peso"], $_POST["altura"], $_POST["n_camisola"], $_POST["n_intern"], $cod_sel);
                    echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
                } else {
                    echo "<script language=javascript>alert( 'Jogador já existente!' );</script>";
                }
            }
        } else {
            echo "<script language=javascript>alert( 'Já registou 23 jogadores!' );</script>";
        }
    }
}
?>
<div class="registo">
    <h1> Registar Jogador </h1>
    <form method="post">
        <p>Nome:<input type="text" name="nome"  title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value=""></p>
        <p>Posição:
            <select name="posicao">
                <option value="Guarda-redes">Guarda-Redes</option> 
                <option value="Defesa">Defesa</option> 
                <option value="Médio">Médio</option> 
                <option value="Avançado">Avançado</option> 
            </select>
        <p>Data de Nascimento: <input type="date" required name="data_nasc" placeholder="aaaa-mm-dd" value=""></p>
        <p>Grupo Sanguíneo:
            <select name="g_sanguineo">
                <option value="A+">A+</option> 
                <option value="A-">A-</option> 
                <option value="AB+">AB+</option> 
                <option value="AB-">AB-</option> 
                <option value="B+">B+</option> 
                <option value="B-">B-</option> 
                <option value="O+">O+</option> 
                <option value="O-">O-</option> 
            </select></p>
        <p>Peso: <input type="number" title="Apenas numeros" placeholder="Kilos" min="0" max="150" pattern="[0-9]+" required name="peso" value=""></p>
        <p>Altura:<input type="number" title="Apenas numeros" placeholder="Centimetros" min="0" max="150" pattern="[0-9]+" required name="altura" value=""></p>
        <p>Nº Camisola:<input type="number" title="Apenas numeros"  min="0" max="23" pattern="[0-9]+" required name="n_camisola" value=""></p>
        <p>Nº Internacionalizações:<input type="number" title="Apenas numeros"  min="0"  pattern="[0-9]+" required name="n_intern" value=""></p>
        <input type="submit" value="Registar" >
    </form>
</div>
<?php
} else {
echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
