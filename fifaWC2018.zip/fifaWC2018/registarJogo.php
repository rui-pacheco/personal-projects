<?php
include("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

if (isset($_POST["data_jogo"])) {
if (regista_jogo($_POST["data_jogo"])) {
        echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
    }
}
?>
<div class="registo">
    <h1>Criar Jogo</h1>
    <form method="post">
        <p>Data: <input type="datetime" required name="data_jogo" placeholder="aaaa-mm-dd hh-mm-ss" value=""></p>
        <input type="submit" value="Criar">
    </form>
</div>
<?php
} else {
echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
