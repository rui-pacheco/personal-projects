<?php
include("top.php");
include 'isAlterado.php';
$dados=get_dados_utilizador($_GET["id"]);
//if (isset($_POST["morada"])) {
//    edita_dados_utilizador($_GET["id"], $_POST["mail"], $_POST["data_nasc"], $_POST["pass"],$_POST["telemovel"], $_POST["morada"]);
//    redirect("editarDados.php?id=$_GET[id]");
//}
?>
<div class="registo">
        <h1> <?= $dados["nome"] ?> - <?php
            if ($dados["Perfis_id_perfil"] == 1) {
                echo "ADMIN";
            } else if ($dados["Perfis_id_perfil"] == 2) {
                echo "LOC";
            } else if ($dados["Perfis_id_perfil"] == 3) {
                echo "CD";
            }
            ?></h1>
    <p><span class="upc"><b>País</b>:</span> <?= $dados["Selecoes_cod_sel"] ?></p>
        <p><span class="upc"><b>Email</b>:</span>  <?= $dados["mail"] ?></p>
        <p><span class="upc"><b>Data de Nascimento</b>:</span>  <?= $dados["data_nasc"] ?></p>
<!--        <p>Password: <?= $dados["pass"] ?></p>-->
        <p><span class="upc"><b>Telemóvel</b>:</span>  <?= $dados["telemovel"] ?></p>
        <p><span class="upc"><b>Morada</b>:</span>  <?= $dados["morada"] ?></p>

</div>

