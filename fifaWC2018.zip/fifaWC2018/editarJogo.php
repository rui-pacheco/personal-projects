<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
    if (isset($_GET['provi'])) {
        $grupos = get_descricao_grupos();
        ?>
        <div class="registo">
            <h1> Editar Jogo </h1>
            <form method="get" >
                <div>
                    <p>Grupo:
                        <select name="id_grupo">
                            <?php for ($i = 0; $i < count($grupos); $i++) { ?>
                                <option value="<?= $grupos[$i]['id_grupo'] ?>"><?= $grupos[$i]['descricao'] ?></option>
                            <?php }
                            ?>
                        </select>


                        <input type="hidden" name="id_jogo" value=<?= $_GET['id_jogo'] ?>>
                        <input type="hidden" name="data_jogo" value=<?= $_GET['data_jogo'] ?>>
                        <input type="submit" name="tudo" value="submeter" ></p>
                </div>
            </form>
        </div>
        <?php
    } else {
        ?>
        <div class="registo">

            <h1> Editar Jogo </h1>
            <form method="post" action="calendario.php">
                <div>


                    <?php if (isset($_GET['tudo'])) { ?>
                        <p><?= get_descricao_grupo($_GET['id_grupo']) ?> </p>
                        <p>Seleções:
                            <select name="ex_cod_sel1">
                                <?php
                                if (isset($_GET['cod_sel1'])) {
                                    ?>
                                    <option value="<?= $_GET['cod_sel1'] ?>"><?= $_GET['selecao1'] ?></option>
                                    <?php
                                }
                                $selecoes = get_selecoes_by_grupo($_GET['id_grupo']);
                                for ($i = 0; $i < count($selecoes); $i++) {
                                    if ($_GET['cod_sel1'] !== $selecoes[$i]['cod_sel']) {
                                        ?>
                                        <option value="<?= $selecoes[$i]['cod_sel'] ?>"><?= $selecoes[$i]['pais'] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select> vs 
                            <select name="ex_cod_sel2">
                                <?php
                                if (isset($_GET['cod_sel2'])) {
                                    ?>
                                    <option value="<?= $_GET['cod_sel2'] ?>"><?= $_GET['selecao2'] ?></option>
                                    <?php
                                }

                                for ($i = 0; $i < count($selecoes); $i++) {
                                    if ($_GET['cod_sel2'] !== $selecoes[$i]['cod_sel']) {
                                        ?>
                                        <option value="<?= $selecoes[$i]['cod_sel'] ?>"><?= $selecoes[$i]['pais'] ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </p>
                    <?php } else { ?>
                        <p><?= get_descricao_grupo($_GET['id_grupo']) ?> </p>
                        <p> <b><?= $_GET['selecao1'] ?></b> vs <b><?= $_GET['selecao2'] ?></b> </p>
                    <?php }
                    ?>

                    <p>Data e hora: <input type="datetime" name="data_jogo" placeholder="aaaa-mm-dd" value=<?= $_GET['data_jogo'] ?>></p>
                    <p>Estádio:
                        <select name="estadio">
                            <?php
                            if (isset($_GET['id_estadio'])) {
                                ?>
                                <option value="<?= $_GET['id_estadio'] ?>"><?= $_GET['estadio'] ?></option>
                                <?php
                            }
                            $estadios = get_nome_estadios();
                            for ($i = 0; $i < count($estadios); $i++) {
                                if ($_GET['id_estadio'] !== $estadios[$i]['id_estadio']) {
                                    ?>
                                    <option value="<?= $estadios[$i]['id_estadio'] ?>"><?= $estadios[$i]['nome'] ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select></p>
                    <?php
                    if (isset($_GET['cod_sel1'])) {
                        ?>
                        <input type="hidden" name="ex_cod_sel1" value="<?= $_GET['cod_sel1'] ?>">
                        <input type="hidden" name="ex_cod_sel2" value="<?= $_GET['cod_sel2'] ?>">
                    <?php }
                    ?>


                    <input type="hidden" name="id_jogo" value="<?= $_GET['id_jogo'] ?>">
                    <input type="submit" value="editar">
                </div>
            </form>
        </div>

        <?php
    }
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}