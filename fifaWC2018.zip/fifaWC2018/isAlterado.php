<?php
if (isset($_SESSION['id'])) {
        $n_login = get_n_login($_SESSION['id']);
        if ($n_login['n_login'] == 0) {
            redirect("alterarPass.php");
        }
    }?>
