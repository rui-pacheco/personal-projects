<?php
include("top.php");
if (isset($_POST['pass2'])) {
    if ($_POST['pass'] == ($_POST['pass2'])) {
        alteraPass($_POST['pass2'], $_SESSION['id']);
        atualiza($_SESSION['id']);
        redirect('homepage.php');
    } else {
        echo "<script language=javascript>alert( 'As passwords não são iguais!' );</script>";
    }
}

?>
<div class="registo">
    <form method="post">
        <h1>Alterar Password</h1>
        <p> Password: <input type="password" name="pass" value="" required></p>
        <p> Repetir Password: <input type="password" name="pass2" value="" required></p>
        <input type="submit" value="editar">
    </form>
</div>
