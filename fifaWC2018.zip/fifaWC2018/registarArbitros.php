<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

if (isset($_POST["nome"], $_POST["data_nasc"], $_POST["nacionalidade"])) {
    $nome = $_POST["nome"];
    $data_nasc = $_POST["data_nasc"];
    $nac = $_POST["nacionalidade"];
    if (regista_arbitro($nome, $data_nasc, $nac)) {
        echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
    }
}
?>

<div class="registo">
    <h1>Registar Árbitro</h1>
    <form method="post">
        <p>Nome: <input type="text" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="nome" value=""></p>
        <p>Data de Nascimento: <input type="date" required name="data_nasc" placeholder="aaaa-mm-dd" value=""></p>
        <p>Nacionalidade: <input type="text" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="nacionalidade" value=""></p>
        <input type="submit" value="Registar">
    </form>
</div>
<?php
} else {
echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
