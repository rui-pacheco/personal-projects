<?php
include 'top.php';
include 'isAlterado.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Place Autocomplete Hotel Search</title>
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <meta charset="utf-8">
        <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true&libraries=places"></script>
        <script type="text/javascript" src="./javascript/conversor.js"></script>

    </head>

    <body onload="initialize()">

        <div style="float:right; margin-right: 5%">
            <div id="map-canvasH"></div>

            <div id="listingH">
                <table id="resultsTableH">
                    <tbody id="results"></tbody>
                </table>
            </div></div>


       


        <div id="conversor">


            <h2 style="background-color: #333333; color:white "> Encontre hoteis em: </h2>

            <div>
                <input id="autocomplete" placeholder="Escolha uma cidade" type="text" />
            </div>

            <div>
                <select id="country">
                    <option value="all">Todos</option>
                    <option value="ru" selected>Russia</option>

                </select>
            </div>
            <br>
            <br>
            <hr>
            <br>
            <br>

            <script type="text/javascript"   src="http://pt.exchange-rates.org/GetCustomContent.aspx?sid=CC000BZFI&amp;type=CurrencyConverter&amp;stk=0BV2UYD5IT" charset="utf-8">
            </script>
            <div>Fonte: <a href="http://pt.exchange-rates.org/">pt.exchange-rates.org</a></div><noscript><iframe ID="frmExchRatesCC000BZFI" style="margin:0px;border:none;padding:0px;" frameborder="0" width="161" height="181" src="http://pt.exchange-rates.org/GetCustomContent.aspx?sid=CC000BZFI&amp;type=CurrencyConverter&amp;submit=submit&amp;stk=0XFNDG65IU"></iframe></noscript>

        </div>
            
            <div id="map-canvasH"></div>

            <div id="listingH">
                <table id="resultsTableH">
                    <tbody id="results"></tbody>
                </table>
            </div>
            
            
            <div id="info-content">
            <table>
                <tr id="iw-url-row" class="iw_table_rowH">
                    <td id="iw-icon" class="iw_table_iconH"></td>
                    <td id="iw-url"></td>
                </tr>
                <tr id="iw-address-row" class="iw_table_rowH">
                    <td id="cona" class="iw_attribute_name"></td>
                    <td id="iw-address"></td>
                </tr>
                <tr id="iw-phone-row" class="iw_table_rowH">
                    <td id="cona1" class="iw_attribute_name"></td>
                    <td id="iw-phone"></td>
                </tr>
                <tr id="iw-rating-row" class="iw_table_rowH">
                    <td id="cona2" class="iw_attribute_name"></td>
                    <td id="iw-rating"></td>
                </tr>
                <tr id="iw-website-row" class="iw_table_rowH">
                    <td id="cona3" class="iw_attribute_name"></td>
                    <td id="iw-website"></td>
                </tr>
            </table>
        </div>
    </body>
</html>



