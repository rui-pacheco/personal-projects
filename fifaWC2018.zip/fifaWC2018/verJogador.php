<?php
include ("top.php");
if (isset($_GET["id_jogador"], $_GET["nome"])) {
    $jogador = get_jogador($_GET["id_jogador"]);
}
?>
<div class="registo">
    <h1> <?= $jogador["nome"] ?> </h1>
        <p><span class="upc"><b>Posição</b>: </span><?= $jogador["posicao"] ?></p>
        <p><span class="upc"><b>Data de Nascimento</b>: </span><?= $jogador["data_nasc"] ?></p>
        <p><span class="upc"><b>Grupo Sanguíneo</b>: </span><?= $jogador["g_sanguineo"] ?></p>
        <p><span class="upc"><b>Peso</b>: </span><?= $jogador["peso"] ?></p>
         <p><span class="upc"><b>Altura</b>: </span><?= $jogador["altura"] ?></p>
        <p><span class="upc"><b>Nº Camisola</b>: </span><?= $jogador["n_camisola"] ?></p>
        <p><span class="upc"><b>Nº Internacionalizações</b>: </span><?= $jogador["n_intern"] ?></p>
</div>

