<?php
include("top.php");
include 'isAlterado.php';
if (isset($_GET["remover"]) && null !== $_GET["remover"]) {
    if (remover_arbitros($_GET["remover"])) {
        echo "<script language=javascript>alert( 'Árbitro removido com sucesso!' );</script>";
    }
}
?>
<div class="fundo">
    <h1> Árbitros  <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1){?><a href="registarArbitros.php"><input type="submit" value="Registar"> </a><?php } ?></h1>
        <?php get_arbitros(); ?>
</div>


