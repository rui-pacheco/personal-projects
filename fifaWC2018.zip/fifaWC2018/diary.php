<?php

require_once 'funcoes.php';
require_once 'mysql.connect.php';
require_once 'class.phpmailer.php';
$noticias = listar_noticias();
$mensagemFinal="";
if(count($noticias)>0){
    $mensagemFinal="<h1 style='text-align:center'>FIFAWC2018 - Principais Notícias do dia</h1>";
for ($i = 0; $i < count($noticias); $i++) {
    
    $titulo = $noticias[$i]['titulo'];
    $data = $noticias[$i]['data'];
    $descricao = $noticias[$i]['descricao'];
    $mensagemFinal = "$mensagemFinal <h3><b> $titulo $data </b></h3> $descricao<br>";
}
}
$assunto = "Newsletter FifaWC2018";
$mensagemFinal = utf8_decode($mensagemFinal);
$subscritores = getSubscritos('diario');
$emails = "";
for ($i = 0; $i < count($subscritores); $i++) {
    $email = $subscritores[$i]['email'];
    if ($i == count($subscritores) - 1) {
        $emails = "$emails$email";
    } else {
        $emails = "$emails$email ; ";
    }
}
enviarEmail($assunto, $mensagemFinal, $emails);




