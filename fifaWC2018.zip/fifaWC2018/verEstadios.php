<?php
include("top.php");
include 'isAlterado.php';
if (isset($_GET["remover"]) && null !== $_GET["remover"]) {
    if (remover_estadio($_GET["remover"])) {
        echo "<script language=javascript>alert( 'Estádio removido com sucesso!' );</script>";
    }else{
            echo "<script language=javascript>alert( 'Não é possivel remover este estádio, pois já se realizaram jogos nele!' );</script>";

    }
}
?>

<div class="fundo">
    <h1>Estádios
        <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 2) { ?><a href="registarEstadios.php">
                <input type="submit" value="Registar">
            </a><?php } ?></h1>
    <?php get_estadios(); ?>
    <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
        get_estadios_incompletos();
    } ?>
</div>


