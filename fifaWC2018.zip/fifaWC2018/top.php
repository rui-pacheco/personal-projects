<?php
require_once 'funcoes.php';
session_start();
$mail = "";
if (isset($_GET['logout'])) {
    session_destroy();
    redirect("homePage.php");
}
//Vejo se recebo dados do formulário
if (isset($_GET["estilo"])) {
    //é que estou recebendo um estilo novo, tenho que colocá-lo nas cookies
    $estilo = $_GET["estilo"];
    //coloco o estilo em uma cookie
    setcookie("estilo", $estilo, time() + (60 * 60 * 24 * 90)); //90dias
} else {
    //se não recebi o estilo que deseja o usuário na página, vejo se há uma cookie criada
    if (isset($_COOKIE["estilo"])) {
        //é que tenho a cookie
        $estilo = $_COOKIE["estilo"];
    }
}
if (isset($_POST['pass'])) {
    $mail = $_POST['mail'];
    $pass = $_POST['pass'];
    $dados = valida_utilizador($mail, $pass);

    if ($dados) {
        $valido = TRUE;
        $_SESSION['id'] = $dados['id_utilizador'];
        $_SESSION['mail'] = $dados['mail'];
        $_SESSION['nome'] = $dados['nome'];
        $_SESSION['perfil'] = $dados['Perfis_id_perfil'];
        $_SESSION['cod_sel'] = $dados['Selecoes_cod_sel'];
    }
    include 'isAlterado.php';
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Fifa World Cup 2018</title>
        <link rel="icon" href="Imagens/mundial.png" type="image/png"> <!--ícone no topo da pagina-->
        <?php
//vejo se tive um estilo definido, porque então tenho que carregar a correspondente folha de estilos
        if (isset($estilo)) {
            echo "<link rel='stylesheet' type='text/css' href=$estilo>";
        }else{
            echo "<link rel='stylesheet' type='text/css' href='allcss.css'>";
        }
        ?>

    </head>
    <body>

        <nav class="top">
            <ul>
                <li class="logo"><a id="espaco" href="homePage.php"><img src="Imagens/wc2018.jpg"></a></li> 
                <li><a href="selecoes.php">Seleções</a></li>
                <li><a href="calendario.php">Calendário</a></li>
                <li><a href="verGrupos.php">Grupos</a></li> 
                <li><a href="eliminatorias.php">Eliminatórias</a></li>
                <li><a href="verEstadios.php">Estádios</a></li> 
                <li><a href="estatisticas.php">Estatísticas</a></li> 
                <li><a href="verArbitros.php">Árbitros</a></li>
                <?php
                if (isset($_SESSION['perfil']) == false || $_SESSION['perfil'] != 1) {
                    ?><li><a href="comentarios.php">Comentários</a></li>
                        <?php
                    }


                    if (isset($_SESSION['perfil'])) {
                        if ($_SESSION['perfil'] == 1) {
                            ?>
                        <li><a href="#">Registo</a>
                            <ul>
                                <li><a href="registo.php?perfil=LOC">LOC</a></li>
                                <li><a href="registo.php?perfil=CD">CD</a></li>
                            </ul></li>
                        <?php
                    }
                }
                if (isset($_SESSION['mail'])) {
                    ?>
                    <li><a href="#"><?= "Olá, " . $_SESSION['nome'] ?></a>
                        <ul><?php if ($_SESSION['perfil'] == '1') {
                        ?> <li><a href="verUtilizadores.php">Utilizadores</a></li> 
                                <li><a href="comentarios.php">Comentários</a></li> 
                            <?php } ?>
                            <li><a href="editarDados.php?id=<?= $_SESSION['id'] ?>">Editar dados</a></li>
                            <li><a href="verDados.php?id=<?= $_SESSION['id'] ?>">Ver perfil</a></li>
                            <li><a href="top.php?logout=1">Terminar sessão</a></li>
                        </ul>
                    </li>
                    <li id="procura"><form method="post" action="pesquisa.php"><input  type="search" name="procura" placeholder="Pesquisar"></li></form>
                    <?php } else {
                        ?>
                    <li><a href="">Login</a>
                        <ul>
                            <form method="post">
                                <li>Email:<input type="email" name="mail" value=<?= $mail ?>></li>
                                <li>Password:<input type="password" id="password" name="pass" />
                                    <?php
                                    if (isset($valido) && $valido !== TRUE) {
                                        echo 'Dados inválidos';
                                    }
                                    ?>
                                </li>
                                <li><input type="submit" value="Entrar">
                                    <a href="recuperarPass.php" style="padding: 0px;display: inline-block;"><input type="button" value="Recuperar Pass"></a></li>
                            </form>
                        </ul>
                    </li>  
                    <li id="procura"><form method="post" action="pesquisa.php"><input  type="search" name="procura" placeholder="Pesquisar"></li></form>
                    <?php } ?>
                        <div style="float: right;margin-top: -17px"><a  href="top.php?estilo=allcss.css"> <input style="background-color: #efefef;"class="css" type="button" value=""></a>
                        <a  href="top.php?estilo=allcss1.css"> <input style="background-color: blue;" class="css" type="button" value=""></a>
                        <a  href="top.php?estilo=allcss2.css"> <input style="background-color: red;" class="css" type="button" value=""></a>

                    </div> </ul>
        </nav>


<!--        <input class="css" type="button" value="">
    <input class="css" type="button" value="">
    <input class="css" type="button" value="">-->

