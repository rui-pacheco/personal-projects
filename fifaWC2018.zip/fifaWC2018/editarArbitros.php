<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

if (isset($_POST["nome"], $_POST["data_nasc"], $_POST["nacionalidade"])) {
    atualiza_arbitros($_POST["nome"], $_POST["data_nasc"], $_POST["nacionalidade"],$_GET['id_arbitro']);
    redirect("verArbitros.php");
}
?>
<div class="registo">
    <h1> Editar arbitro </h1>
    <form method="post">
        <p>Nome: <input type="text" name="nome" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value="<?= $_GET['nome'] ?>"></p>
        <p>Data de nascimento: <input type="date" name="data_nasc" placeholder="aaaa-mm-dd" required value=<?= $_GET['data_nasc'] ?>></p>
        <p>Nacionalidade: <input type="text" name="nacionalidade" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value="<?= $_GET['nacionalidade'] ?>"></p>
    <input type="submit" value="Editar">
    </form>
    
</div>    
<?php } else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}