<?php
include("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

if(isset($_GET["nome"])){
    $utilizador=getUtilizadores_by_id($_GET["id"]);
}
?>
<div class="registo">
 <h1> <?= $_GET["nome"] ?> - <?= $_GET["perfil"] ?></h1>
        <p><span class="upc"><b>País</b>:</span> <?= $utilizador["Selecoes_cod_sel"] ?></p>
        <p><span class="upc"><b>Email</b>:</span>  <?= $utilizador["mail"] ?></p>
        <p><span class="upc"><b>Data de Nascimento</b>:</span>  <?= $utilizador["data_nasc"] ?></p>
        <p><span class="upc"><b>Telemóvel</b>:</span>  <?= $utilizador["telemovel"] ?></p>
        <p><span class="upc"><b>Morada</b>:</span>  <?= $utilizador["morada"] ?></p>
</div>
<?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}