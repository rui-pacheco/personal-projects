<?php
include("top.php");
include 'isAlterado.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

    if (isset($_POST["morada"])) {
        if (existe_utilizador($_POST["mailReg"]) == 0) {
            if ($_GET['perfil'] == 'LOC') {

                if (regista_utilizador($_POST["nome"], $_POST["mailReg"], getCodSelecao('Russia'), $_POST["data_nasc"], $_POST["telemovel"], $_POST["morada"], 2, 0)) {
                    echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
                }
            } else if ($_GET['perfil'] == 'CD') {
                if (regista_utilizador($_POST["nome"], $_POST["mailReg"], $_POST["pais"], $_POST["data_nasc"], $_POST["telemovel"], $_POST["morada"], 3, 0)) {
                    echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
                }
            }
        } else {
            echo "<script language=javascript>alert( 'Já existe um utilizador com esse email!' );</script>";
        }
    }
    ?>
    <div class="registo">
        <h1> Registo </h1>
        <form method="post">
            <p>Tipo de utilizador: <?= $_GET['perfil'] ?></p>
            <p>Nome: <input type="text" name="nome" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value=""></p>
            <p>Email:<input type="email" name="mailReg" required value=""></p>
            <?php if ($_GET['perfil'] == 'CD') { ?>
                <p>País:
                    <select name="pais">
                        <?php
                        $selecoes = get_nome_selecoes();
                        for ($i = 0; $i < count($selecoes); $i++) {
                            ?>
                            <option value="<?= $selecoes[$i]['cod_sel'] ?>"><?= $selecoes[$i]['pais'] ?></option> 
                        <?php } ?>
                    </select>
                </p> <?php } else { ?><p>País: Russia</p><?php } ?>
            <p>Data de Nascimento:<input type="date" name="data_nasc" required value=""></p>
            <p>Telemóvel:<input type="tel" name="telemovel" title="Apenas numeros" pattern="[0-9]+" required value=""></p>
            <p>Morada:<input type="text" name="morada" required value=""></p>

            <input type="submit" value="Registar" >
        </form>
    </div>

    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}