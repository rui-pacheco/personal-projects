<?php
include 'top.php';
?>
    <p style=" margin:0% 0% 0% 73% " >
        <input style=" border: 1px solid black; " type="text" id="start"  value="" placeholder="Origem">
        <input style=" border: 1px solid black; " type="button" onclick="calcRoute()" value="Calcular" >
    </p>

    <div id="meteo" >

    <h1 id="cidade"><?= get_cidade($_GET["id_estadio"]) ?></h1>
    <br>
    <div style="margin-top: -20%;margin-bottom:  -25%">
        <div style="float: left; float: top;  margin-top: 12%"  class="tempe"><img style="padding-right:0,5em;" id="icone" /></div> 
        <div style="float: right ; float: top; " class="tempe" ><h1 id="temperatura"> </h1></div>
    </div>
    <div style="float: bottom;  margin-top: 50%;" >
        <h4 style="margin-top:  -10%" id="tempo"></h4>
        <p style="margin-top:  -10%"id="data"></p>
        <br>

    </div>
    <div style="float: left; width: 50%; display: inline-block" >
        <img  id="prev1" style="display:block ;  padding-right: 10%">
        <img  id="prev2" style="display: block">
        <img  id="prev3" style="display: block">
    </div>
    <div style="float: left; float: top;display: inline-block; ">
        <p id="data1"></p>
        <p id="data2" style="padding-top: 20%"></p>
        <p id="data3" style="padding-top: 20%"></p>
    </div>


</div>

<script src="http://maps.google.se/maps/api/js?sensor=false"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&signed_in=true"></script>
<script type="text/javascript" src="./javascript/instrucoes.js"></script>


<div id="map-canvas" style="border:1px solid black" ></div>



<input id="address" type="hidden" value="<?= get_cordenadas($_GET['id_estadio']) ?>">




