<?php
include("top.php");
include 'isAlterado.php';
$dados = get_dados_utilizador($_GET["id"]);
if (isset($_POST["morada"])) {
    if ($_POST['pass'] == ($_POST['pass2'])) {
        edita_dados_utilizador($_GET["id"], $_POST["mail"], $_POST["data_nasc"], $_POST["pass"],$_POST["telemovel"], $_POST["morada"]);
        echo "<script language=javascript>alert( 'Utilizador editado com sucesso!' );</script>";

    } else {
        echo "<script language=javascript>alert( 'As passwords não são iguais!' );</script>";
    }
}
?>
<div class="registo">
    <form method="post">
        <h1> <input type="text" value="<?= $dados["nome"] ?>"> - <?php
            if ($dados["Perfis_id_perfil"] == 1) {
                echo "ADMIN";
            } else if ($dados["Perfis_id_perfil"] == 2) {
                echo "LOC";
            } else if ($dados["Perfis_id_perfil"] == 3) {
                echo "CD";
            }
            ?></h1>
        <p><span class="upc"><b>País</b>:</span> <?= $dados["Selecoes_cod_sel"] ?></p>
        <p><span class="upc"><b>Email</b>:</span> <input type="mail" name="mail" required value="<?= $dados["mail"] ?>"></p>
        <p><span class="upc"><b>Data de Nascimento</b>:</span> <input type="date" placeholder="aaaa-mm-dd" required name="data_nasc" value=<?= $dados["data_nasc"] ?>></p>
        <p><span class="upc"><b>Password</b>:</span> <input type="password" name="pass" required value="<?= $dados["pass"] ?>"></p>
        <p><span class="upc"><b>Repetir Password</b>:</span> <input type="password" required name="pass2" value="<?= $dados["pass"] ?>"></p>
        <p><span class="upc"><b>Telemóvel</b>:</span> <input type="tel" title="Apenas numeros" pattern="[0-9]+" required name="telemovel" value="<?= $dados["telemovel"] ?>"></p>
        <p><span class="upc"><b>Morada</b>:</span> <input type="text" name="morada" required value="<?= $dados["morada"] ?>"></p>
        <input type="submit" value="Editar">
    </form>
</div>
