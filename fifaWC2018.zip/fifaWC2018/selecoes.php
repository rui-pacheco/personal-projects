<?php
include("top.php");
include 'isAlterado.php';
if (isset($_SESSION['id'])) {
    $n_login = get_n_login($_SESSION['id']);
    if ($n_login['n_login'] == 0) {
        redirect("alterarPass.php");
    }
}
if (isset($_GET["remover"])) {
    if (remove_selecao($_GET["remover"])) {
        echo "<script language=javascript>alert( 'Seleção removida com sucesso!' );</script>";
    }
}
?>
<div class="fundo">
    <h1> Seleções <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?><a href="registarSelecao.php"><input type="submit" value="Registar"></h1></a>
        <?php } ?>
        <?php get_selecoes(); ?>
            <?php if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) { ?> <h1> Seleções Incompletas</h1>
                <?php get_selecoes_incompletas();
            } ?>
</div>

