<html>
    <body>
        <div>
            <footer>
                <div class="footer">
                    <div>
                        <p><a href="noticias.php"><img style="width: 2.5%;height: 4.5%" src="Imagens/rss.png" alt="0"></a>  Copyright © PW- Grupo 103 - Universidade do Minho   
                            <a href="feedFifa.php">
                                <img style="width: 2.5%;height: 4.5%" src="Imagens/moedas.png" alt="0"/>
                            </a>
                            <a style="float: right; margin: 1%" href="subscrever.php">Subscrever Newsletters</a>
                        </p>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
