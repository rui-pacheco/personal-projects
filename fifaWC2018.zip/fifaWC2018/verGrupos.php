<?php
include("top.php");
include 'isAlterado.php';
if (isset($_GET["remover"])) {
    if (remove_grupo($_GET["remover"])) {
        echo "<script language=javascript>alert( 'Grupo removido com sucesso!' );</script>";
    }
}
?>
<div class="fundo">
    <h1>Grupos
    <?php if (isset($_SESSION['id']) && $_SESSION['id'] == 1) { ?><a href="registarGrupos.php"> 
            <input type="submit" value="Registar">
    </a><?php } ?></h1>
    <?php
    get_grupos();
    ?>
</div>

