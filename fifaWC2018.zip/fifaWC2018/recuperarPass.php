<?php
include 'top.php';
if(isset($_POST['mailrecupera'])){
    recuperarPass($_POST['mail']);
}
?>
<div class="registo">
        <h1>Recuperar Pass</h1>
        <form method="post">
            <p>Insira o seu e-mail: 
                <input type="email" name="mailrecupera" required value="">
            </p>
                <input type="submit" value="Ok">
        </form>
</div>