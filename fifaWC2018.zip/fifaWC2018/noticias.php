<?php
include 'top.php';
$xml = ("http://rss.feedsportal.com/c/32502/f/480420/index.rss");
$xml1 = ("http://feeds.ojogo.pt/OJ-Ultimas");
?> <div class="fundo">
    <h1> Últimas Notícias</h1><?php
        $xmlDoc1 = new DOMDocument();
        $xmlDoc1->load($xml1);
        $feed1 = array();
        foreach ($xmlDoc1->getElementsByTagName('item') as $node1) {
            $item1 = array(
                'title' => $node1->getElementsByTagName('title')->item(0)->nodeValue,
                'desc' => $node1->getElementsByTagName('description')->item(0)->nodeValue,
                'link' => $node1->getElementsByTagName('link')->item(0)->nodeValue,
                'date' => $node1->getElementsByTagName('pubDate')->item(0)->nodeValue,
            );
            array_push($feed1, $item1);
        }
        $limit1 = 8;
        for ($x1 = 0; $x1 < $limit1; $x1++) {
            $title1 = str_replace(' & ', ' &amp; ', $feed1[$x1]['title']);
            $link1 = $feed1[$x1]['link'];
            $description1 = $feed1[$x1]['desc'];
            $date1 = date('l F d, Y', strtotime($feed1[$x1]['date']));
            echo '<div class="noticia"><h3><strong><a href="' . $link1 . '" title="' . $title1 . '">' . $title1 . '</a></strong><br />';
            echo '<small><em>Posted on ' . $date1 . '</em></small></h3>';
            echo '<p id="texto">' . $description1 . '</p></div>';
        }
        $xmlDoc = new DOMDocument();
        $xmlDoc->load($xml);
        $feed = array();
        foreach ($xmlDoc->getElementsByTagName('item') as $node) {
            $item = array(
                'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,
                'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,
                'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,
                'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,
            );
            array_push($feed, $item);
        }
        $limit = 8;
        for ($x = 0; $x < $limit; $x++) {
            $title = str_replace(' & ', ' &amp; ', $feed[$x]['title']);
            $link = $feed[$x]['link'];
            $description = $feed[$x]['desc'];
            $date = date('l F d, Y', strtotime($feed[$x]['date']));
            echo '<div class="noticia"><h3><strong><a href="' . $link . '" title="' . $title . '">' . $title . '</a></strong><br />';
            echo '<small><em>Posted on ' . $date . '</em></small></h3>';
            echo '<p id="texto">' . $description . '</p></div>';
        }
        ?>
    <br></div>
