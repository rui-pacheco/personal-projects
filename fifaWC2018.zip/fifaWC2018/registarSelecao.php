<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
    if (isset($_POST["pais"])) {
        $cod = $_POST["codigo"];
        $pais = $_POST["pais"];
        if (regista_selecao($cod, $pais)) {
            echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
        }
    }
    ?>
    <div class="registo">
        <h1>Registar Seleção</h1>
        <form method="post">
            <p>Código: <input type="text" maxlength="4" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="codigo" value=""></p>
            <p>País: <input type="text" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="pais" value=""></p>
            <input type="submit" value="Registar">
        </form>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
