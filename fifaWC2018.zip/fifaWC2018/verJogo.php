<?php
include("top.php");
if (isset($_GET['id_jogo'])) {
    $estadio = get_estadio_jogo($_GET['id_jogo']);
    $fase = get_fase_data_jogo($_GET['id_jogo']);
    $golos = get_golos($_GET['id_jogo']);
    for ($i = 0; $i < count($golos); $i++) {
        if ($golos[$i]['pais'] == $_GET["selecao1"]) {
            $golosSel1[] = $golos[$i];
        } else {
            $golosSel2[] = $golos[$i];
        }
    }
}
?>
<body id="verJogo">
    <div id="campo">
        <div style="margin-left: 33%;">
            <div id="verJogoCasa"><h1><?= $_GET["selecao1"] ?></h1></div>
            <div style="float: left; width: 5%; text-align: center;margin-top: -3%;">
                <h1 style="background-color: black;">
                    <span style="color:White;"><?= $_GET["golos1"] ?></span></h1>
            </div></div>
        <div style="margin-left: 33%;">
            <div style="float: left; width: 5%; text-align: center;margin-top: -3%;">
                <h1 style="background-color: black;">
                    <span style="color:White;"><?= $_GET["golos2"] ?></span></h1>
            </div>
            <div id="verJogoFora"><h1><?= $_GET["selecao2"] ?></h1></div></div><br><br>
        <?php
        if (isset($golosSel1)) {
            ?><div style="margin-top: 10px;margin-left: -32%;display: inline-block">
                <table style="margin-right: 80px"><?php
                for ($i = 0; $i < count($golosSel1); $i++) {
                    ?><tr><td>
                            <span style="color:Black;font-weight:bold;font-size: 11px;"><?= $golosSel1[$i]['nome'] ?></span>
                            <span style="color:Black;font-weight:bold;font-size: 11px;"><?php
                                if ($golosSel1[$i]['autogolo'] == 0) {
                                    
                                } else {
                                    echo 'Autogolo';
                                }
                                ?></span>
                            <span style = "font-weight:bold;font-size: 11px;"> - <?= $golosSel1[$i]['minuto']
                                ?></span>
                            <img src="Imagens/golo.png" style="border-style:None;height:12px;width:12px;border-width:0px;"><br>
                        </td></tr>
                <?php } ?></table></div>
        <?php }
        if (isset($golosSel2)) {
            ?><div style="display: inline-block;">
            <table><?php
                for ($i = 0; $i < count($golosSel2); $i++) {
                    ?><tr><td>
                            <img src="Imagens/golo.png" style="border-style:None;height:12px;width:12px;border-width:0px;margin-left: 10%">
                            <span style="font-weight:bold;font-size: 11px;"><?= $golosSel2[$i]['minuto']
                    ?> - </span>
                            <span style="color:Black;font-weight:bold;font-size: 11px;"><?= $golosSel2[$i]['nome'] ?></span>
                            <span style="color:Black;font-weight:bold;font-size: 11px;"><?php
                                if ($golosSel2[$i]['autogolo'] == 0) {
                                    
                                } else {
                                    echo 'Autogolo';
                                }
                                ?></span></td></tr>
                                <?php }
                                ?></table></div>
                <?php }
                ?><br>
            <div style="margin-left: 14%;">
                <span class="upc"><b>Data:</b></span> <?php
                if (isset($_GET["data"])) {
                    echo $_GET["data"];
                } else {
                    if ($fase['data_jogo'] !== null) {
                        echo $fase['data_jogo'];
                    } else {
                        echo 'Por definir';
                    }
                }
                ?><br>
                <span class="upc"><b> Fase:</b> </span><?php
                if (isset($_GET["fase"])) {
                    echo $_GET["fase"];
                } else {
                    echo $fase['fase'];
                }
                ?><br>
                <span class="upc"><b>Estádio:</b></span> <?php
                if (isset($_GET["estadio"])) {
                    echo $_GET["estadio"];
                } else {
                    if ($estadio['nome'] !== null) {
                        echo $estadio['nome'];
                    } else {
                        echo 'Por definir';
                    }
                }
                ?></div><br>
            <div style="display: inline-block;margin-left:20%"><table class="tableJogo">
                    <tr>
                        <th>Nº</th>
                        <th>Jogador</th>
                    </tr>

                    <?php
                    $jog1 = get_jogadores_uti_by_cod_sel($_GET["cod_sel1"], $_GET["id_jogo"]);
                    for ($i = 0; $i < count($jog1); $i++) {
                        ?>
                        <tr>
                            <td><?= $jog1[$i]["n_camisola"] ?></td>
                            <td><?= $jog1[$i]["nome"] ?></td>
                        </tr>
                    <?php }
                    ?>
                </table>
            </div>
            <div style="display:inline-block;margin-left: 34%">
                <table class="tableJogo">

                    <tr>
                        <th>Nº</th>
                        <th>Jogador</th>
                    </tr>

                    <?php
                    $jog1 = get_jogadores_uti_by_cod_sel($_GET["cod_sel2"], $_GET["id_jogo"]);
                    for ($i = 0; $i < count($jog1); $i++) {
                        ?>
                        <tr>
                            <td><?= $jog1[$i]["n_camisola"] ?></td>
                            <td><?= $jog1[$i]["nome"] ?></td>
                        </tr>
                    <?php }
                    ?>
                </table></div>
            <table class="tableJogo">
                <tr><th>Equipa de arbitragem:</th></tr>
                <tr><th>Nome</th>
                    <th>Nacionalidade</th>
                    <th>Tipo</th></tr>
                <?php
                $arbitrosDestacados = get_arbitros_destacados($_GET['id_jogo']);
                for ($a = 0; $a < count($arbitrosDestacados); $a++) {
                    ?><tr>
                        <td><?= $arbitrosDestacados[$a]['nome'] ?></td>
                        <td><?= $arbitrosDestacados[$a]['nacionalidade'] ?></td>
                        <td><?= $arbitrosDestacados[$a]['descricao'] ?></td></tr>
                    <?php
                }
                ?>
        </table>
        <br/></div>
</body>