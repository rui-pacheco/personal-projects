<?php
include("top.php");
if (isset($_GET["id_staff"], $_GET["nome"])) {
    $staff = get_staff($_GET["id_staff"]);
}
?>
<div class="registo">
    <h1> <?= $staff["nome"] ?> </h1>
    <p>Data de Nascimento: <?= $staff["data_nasc"] ?></p>
    <p>Sexo: <?= $staff["sexo"] ?></p>
    <p>Grupo Sanguíneo: <?= $staff["g_sanguineo"] ?></p>
    <p>Função: <?= $staff["descricao"] ?></p>
</div>

