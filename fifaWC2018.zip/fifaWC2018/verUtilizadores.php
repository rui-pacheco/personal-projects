<?php
include("top.php");
include 'isAlterado.php';
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

    if (isset($_GET['remover'])) {
        if (remover_utilizador($_GET['remover'])) {
            echo "<script language=javascript>alert( 'Utilizador removido com sucesso!' );</script>";
        }
    }
    ?>
    <div class="fundo">
        <h1>Utilizadores</h1>
        <?php $utilizadores = getUtilizadores(); ?>
        <table class="tableGrande">
            <th>Nome</th>
            <th>Email</th>
            <th>Tipo de perfil</th>
            <?php for ($i = 0; $i < count($utilizadores); $i++) {
                ?><tr>
                    <td><?= $utilizadores[$i]['nome'] ?></td>
                    <td><?= $utilizadores[$i]['mail'] ?></td>
                    <?php
                    if ($utilizadores[$i]['Perfis_id_perfil'] == 2) {
                        ?><td>LOC</td>
                        <td><a href="verUtilizador.php?nome=<?= $utilizadores[$i]['nome'] ?>&id=<?= $utilizadores[$i]['id_utilizador'] ?>&perfil=LOC"><input type="submit" value="ver"></a></td>
                        <td><a href="verUtilizadores.php?remover=<?= $utilizadores[$i]['id_utilizador'] ?>"><input type="submit" value="remover"></a></td>
                        <?php
                    } else if ($utilizadores[$i]['Perfis_id_perfil'] == 3) {
                        ?><td>CD</td>
                        <td><a href="verUtilizador.php?nome=<?= $utilizadores[$i]['nome'] ?>&id=<?= $utilizadores[$i]['id_utilizador'] ?>&perfil=CD"><input type="submit" value="ver"></a></td>
                        <td><a href="editarUtilizador.php?nome=<?= $utilizadores[$i]['nome'] ?>&id=<?= $utilizadores[$i]['id_utilizador'] ?>&perfil=CD"><input type="submit" value="editar"></a></td>
                        <td><a href="verUtilizadores.php?remover=<?= $utilizadores[$i]['id_utilizador'] ?>"><input type="submit" value="remover"></a></td>
                        <?php
                    }
                    ?>


                </tr><?php } ?>

        </table>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
