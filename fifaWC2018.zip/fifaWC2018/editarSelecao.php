<?php
include ("top.php");
//if (isset($_SESSION['perfil'])){
//    
//}
if (isset($_GET["cod_sel"], $_GET["pais"])) {
    
}
if (isset($_GET["rem_jogador"])) {
    if (remove_jogador($_GET["rem_jogador"])) {
        echo "<script language=javascript>alert( 'Jogador removido com sucesso!' );</script>";
    }
}
if (isset($_GET["rem_staff"])) {
    if (remove_elemento_staff($_GET["rem_staff"])) {
        echo "<script language=javascript>alert( 'Elemento removido com sucesso!' );</script>";
    }
}
?>
<div class="registo">
    <h1><?= $_GET["cod_sel"] ?> - <?= $_GET["pais"] ?></h1>
    <form method="post">
        <h3> Equipa Técnica <?php
            if (isset($_SESSION['perfil']) && $_GET["cod_sel"] == $_SESSION['cod_sel'] && $_SESSION['perfil'] == 3) {
                ?><a href="registarEqTecnica.php?registar=<?= $_GET["cod_sel"] ?>&pais=<?= $_GET["pais"] ?>"><input type="button" value="Registar"></a></h3>
            <?php
        }
        ?>

        <div>
            <table class="tablePequena">
                <tr> 
                    <th> Nome</th>
                    <th> Função </th>
                </tr>
                <?php
                $staff = get_staff_by_sel($_GET["cod_sel"]);
                if ($staff==null){
                    ?><tr><td colspan="2">Não existem elementos de staff registados</td></tr>
                <?php }
                for ($i = 0; $i < count($staff); $i++) {
                    ?>
                    <tr>
                        <td><?= $staff[$i]["nome"] ?></td>
                        <td><?= $staff[$i]["descricao"] ?></td>
                        <td>
                            <a href="verStaff.php?id_staff=<?= $staff[$i]["id_staff"] ?>&nome=<?= $staff[$i]["nome"] ?>"><input type="button" value="ver"></a>
                            <?php
                            if (isset($_SESSION['perfil']) && $_GET["cod_sel"] == $_SESSION['cod_sel'] && $_SESSION['perfil'] == 3) {
                                ?>
                            <a href="editarEqTecnica.php?edita_staff=<?= $staff[$i]["id_staff"] ?>&nome=<?= $staff[$i]["nome"] ?>"><input type="button" value="Editar"></a>
                            <a href="editarSelecao.php?rem_staff=<?= $staff[$i]["id_staff"] ?>&cod_sel=<?= $_GET["cod_sel"] ?>&pais=<?= $staff[$i]["pais"] ?>"><input type="button" value="Remover"></a>
                                <?php
                            }
                            ?>
                        </td>
                    </tr>

                <?php }
                ?>
            </table>
        </div>
        <h3> Jogadores <?php
            if (isset($_SESSION['perfil']) && $_GET["cod_sel"] == $_SESSION['cod_sel'] && $_SESSION['perfil'] == 3) {
                ?>
            <a href="registarJogador.php?registar=<?= $_GET["cod_sel"] ?>&pais=<?= $_GET["pais"] ?>"><input type="button" value="Registar"></a></h3>
            <?php
        }
        ?>
        <div>
            <table class="tablePequena">
                <tr> 
                    <th> Nome</th>
                    <th> Camisola </th>
                    <th> Posicao </th>
                </tr>
                <?php
                $jogadores = get_jogadores_by_sel($_GET["cod_sel"]);
                if ($jogadores==null){
                    ?><tr><td colspan="3">Não existem jogadores registados</td></tr>
                <?php }
                for ($i = 0; $i < count($jogadores); $i++) {
                    ?>
                    <tr>
                        <td><?= $jogadores[$i]["nome"] ?></td>
                        <td><?= $jogadores[$i]["n_camisola"] ?></td>
                        <td><?= $jogadores[$i]["posicao"] ?></td>
                        <td>
                            <a href="verJogador.php?id_jogador=<?= $jogadores[$i]["id_jogador"] ?>&nome=<?= $jogadores[$i]["nome"] ?>"><input type="button" value="ver"></a>
                            <?php
                            if (isset($_SESSION['perfil']) && $_GET["cod_sel"] == $_SESSION['cod_sel'] && $_SESSION['perfil'] == 3) {
                                ?>
                            <a href="editarJogador.php?edita_jogador=<?= $jogadores[$i]["id_jogador"] ?>&nome=<?= $jogadores[$i]["nome"] ?>"><input type="button" value="Editar"></a>
                            <a href="editarSelecao.php?rem_jogador=<?= $jogadores[$i]["id_jogador"] ?>&cod_sel=<?= $_GET["cod_sel"] ?>&pais=<?= $jogadores[$i]["pais"] ?>"><input type="button" value="Remover"></a>
                                <?php
                            }
                            ?>
                        </td>
                    </tr>

                <?php }
                ?>
            </table>
        </div>
    </form>
</div>

