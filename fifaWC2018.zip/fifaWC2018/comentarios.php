<?php
include("top.php");
if (isset($_POST["comentarios"])) {
    adiciona_comentario($_POST["comentarios"], $_POST["nome"]);
    echo "<script language=javascript>alert( 'Comentário inserido com sucesso!' );</script>";
}
if (isset($_GET["denuncia"])) {
    if (denunciar($_GET["denuncia"])) {
        echo "<script language=javascript>alert( 'Denúncia efetuada!' );</script>";
    }
}
if(isset($_GET['remover'])){
    if(remover_comentario($_GET['remover'])){
        echo "<script language=javascript>alert( 'Comentário removido com sucesso!' );</script>";
    }
}
?>
<div class="fundo">
    <h1>Comentários ao Evento</h1>
    <div class="comment">
        <h2> Inserir Comentário: </h2>
        <form method="post">
            Nome:<input type="text" name="nome" value="" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required><br>
            <textarea rows="4" cols="50" name="comentarios">
            </textarea><br>
            <input type="submit" value="Comentar">
        </form>
            <?php get_comentarios(); ?>
        <br><br>
        <?php
        if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {
                   ?><h2 style="text-align: center"> Denúncias </h2>

           <?php get_denuncias();
        }
        ?>
    </div><br><br><br></div>