<?php
include("top.php");
include 'isAlterado.php';
?>
<div class="fundo">
<h1>Estatísticas</h1>

<?php estatisticasMelhorAtaque(); ?>
<?php estatisticasMelhorDefesa(); ?>
<?php estatisticasMelhorJogador(); ?>
<?php estatisticasJogoMaisGolos(); ?>
<?php jogadorCartoesVermelhos(); ?>
<?php jogadorCartoesAmarelos(); ?>
<?php jogoCartoesVermelhos(); ?>
<?php jogoCartoesAmarelos(); ?>
</div>

