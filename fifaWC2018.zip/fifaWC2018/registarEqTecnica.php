<?php
include("top.php");
    if (isset($_SESSION['perfil']) && isset($_GET["registar"]) && $_SESSION['perfil'] == 3 && $_SESSION['cod_sel'] == $_GET["registar"]) {

if (isset($_GET["registar"], $_GET["pais"])) {
    if (isset($_POST["nome"], $_POST["funcao"], $_POST["data_nasc"], $_POST["sexo"], $_POST["g_sanguineo"])) {
        $cod_sel = $_GET["registar"];
        $id_funcao = get_id_funcao($_POST["funcao"]);
        regista_elemento($_POST["nome"], $_POST["data_nasc"], $_POST["sexo"], $_POST["g_sanguineo"], $cod_sel, $id_funcao);
        echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
    }
}
?>
<div class="registo">
    <h1> Registar Elemento </h1>
    <form method="post">
        <p>Nome:<input type="text" name="nome" title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required value=""></p>
        <p>Função:
            <select name="funcao">
                <?php
                $funcoes = get_funcoes();
                for ($i = 0; $i < count($funcoes); $i++) {
                    ?>
                    <option value="<?= $funcoes[$i] ?>"> <?= $funcoes[$i] ?></option> 
<?php } ?>
            </select>
        <p>Data de Nascimento: <input type="date" name="data_nasc" placeholder="aaaa-mm-dd" required value=""></p>
        <p>Sexo:
            <select name="sexo">
                <option value="M">M</option> 
                <option value="F">F</option> 
            </select>
        </p>
        <p>Grupo Sanguíneo:
            <select name="g_sanguineo">
                <option value="A+">A+</option> 
                <option value="A-">A-</option> 
                <option value="AB+">AB+</option> 
                <option value="AB-">AB-</option> 
                <option value="B+">B+</option> 
                <option value="B-">B-</option> 
                <option value="O+">O+</option> 
                <option value="O-">O-</option> 
            </select></p>
        <input type="submit" value="Registar" >
    </form>

</div>
<?php
} else {
echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}


