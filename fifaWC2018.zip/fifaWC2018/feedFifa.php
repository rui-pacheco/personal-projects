<?php
include 'top.php';
$noticias = listar_noticias();

$rssFeed = '<?xml version="1.0" encoding="UTF-8"?>';
$rssFeed.= "<rss version='2.0'>";
$rssFeed.= "<link rel='stylesheet' type='text/css' href='noticias.css'>";
?><div id="rss"><?php
$rssFeed.="<channel>";
$rssFeed.="<title> Fifa World Cup 2018</title>";
//$rssFeed.="<link>http://localhost/fifaWC2018/</link>";
//$rssFeed.="<description>News</description>";
//$rssFeed.="<language>pt-PT</language>";
?>
    <?php
    for ($i = 0; $i < count($noticias); $i++) {
            $titulo = $noticias[$i]['titulo'];
            $data = $noticias[$i]['data'];
            $descricao = $noticias[$i]['descricao'];
            $rssFeed.="<br><item>";
            $rssFeed.="<title>$titulo $data</title>";
            $rssFeed.="<description> $descricao</description><br>";
            $rssFeed.="</item>";
        }
        ?></div><?php
        $rssFeed.="</channel>";
        $rssFeed.="</rss>";
        echo $rssFeed;