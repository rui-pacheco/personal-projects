<?php
include ("top.php");
if (isset($_SESSION['perfil']) && $_SESSION['perfil'] == 1) {

    if (isset($_POST["descrição"])) {
        $descricao = $_POST["descrição"];
        if (limiteGrupo() < 8) {
            if (registar_grupo($descricao)) {
                echo "<script language=javascript>alert( 'Registo efectuado com sucesso!' );</script>";
            }
        } else {
            echo "<script language=javascript>alert( 'Já existem oitos grupos!' );</script>";
        }
    }
    ?>
    <div class="registo">
        <h1>Registar Grupo</h1>
        <form method="post">
            <div>
                Descrição: <input type="text"  title="Apenas letras" pattern="[a-zA-ZáàãÁÀÃéèÉÈíìÍÌóòõÓÒÕúùÚÙçÇ\s]+" required name="descrição" value=""><br><br>

                <input type="submit" value="Registar">


            </div>
        </form>
    </div>
    <?php
} else {
    echo "<script language=javascript>alert( 'Não tem permissões para aceder a esta página' );</script>";
}
